#!/usr/bin/env python3
"""
ML Analytics Service Orchestrator v1.0.0
Hauptorchestrator für alle ML-Operationen im aktienanalyse-ökosystem

Integration: Event-Driven Architecture (Port 8021)
Autor: Claude Code
Datum: 17. August 2025
"""

import asyncio
import logging
import signal
import sys
import traceback
import asyncpg
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional

import uvicorn
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

# Add project root to Python path
project_root = str(Path(__file__).parent.parent.parent)
sys.path.insert(0, project_root)

# Import configuration
from config.ml_service_config import ML_SERVICE_CONFIG

# Setup simple logging
logging.basicConfig(
    level=logging.INFO,
    format='{"service": "ml-analytics", "level": "%(levelname)s", "message": "%(message)s", "timestamp": "%(asctime)s"}'
)
logger = logging.getLogger("ml-analytics")


class MLAnalyticsService:
    """
    ML Analytics Service Orchestrator
    Verwaltet alle ML-Operationen im Event-Driven System
    """
    
    def __init__(self):
        self.service_name = "ml-analytics"
        self.service_port = ML_SERVICE_CONFIG['service']['port']
        
        # Infrastructure
        self.database_pool = None
        self.app = None
        
        # Service State
        self.is_healthy = False
        self.startup_time = None
        self.shutdown_requested = False
        
    async def initialize_components(self):
        """Initialisiert alle Service-Komponenten"""
        try:
            logger.info("Initializing ML Analytics Service components...")
            
            # Database Connection Pool
            await self._initialize_database()
            
            logger.info("ML Analytics Service components initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize components: {str(e)}")
            logger.error(traceback.format_exc())
            raise
    
    async def _initialize_database(self):
        """Initialisiert PostgreSQL Database Pool"""
        try:
            db_config = ML_SERVICE_CONFIG['database']
            connection_url = (
                f"postgresql://{db_config['user']}:{db_config['password']}"
                f"@{db_config['host']}:{db_config['port']}/{db_config['name']}"
                f"?sslmode=disable"
            )
            
            self.database_pool = await asyncpg.create_pool(
                connection_url,
                min_size=db_config.get('min_connections', 5),
                max_size=db_config.get('max_connections', 20),
                command_timeout=60,
                server_settings={
                    'application_name': 'ml-analytics',
                    'jit': 'off'
                }
            )
            
            # Test connection and check ML schema
            async with self.database_pool.acquire() as conn:
                await conn.execute('SELECT 1')
                
                # Check ML tables
                ml_tables = await conn.fetchval(
                    "SELECT COUNT(*) FROM information_schema.tables WHERE table_name LIKE 'ml_%'"
                )
                
                logger.info(f"Database connection established - {ml_tables} ML tables found")
                
        except Exception as e:
            logger.error(f"Failed to initialize database: {str(e)}")
            raise
    
    async def setup_event_handlers(self):
        """Konfiguriert Event-Handler für ML-Events"""
        try:
            # For now, just log that event handlers would be set up
            logger.info("Event handlers setup (placeholder)")
            
        except Exception as e:
            logger.error(f"Failed to setup event handlers: {str(e)}")
            raise
    
    def _calculate_recommendation_strength(self, predictions: Dict[str, Any]) -> str:
        """Berechnet Empfehlungsstärke basierend auf ML-Predictions (placeholder)"""
        return "NEUTRAL"
    
    async def health_check(self) -> Dict[str, Any]:
        """Comprehensive Health Check"""
        try:
            health_status = {
                'service': 'ml-analytics',
                'version': '1.0.0',
                'status': 'healthy',
                'timestamp': datetime.utcnow().isoformat(),
                'uptime_seconds': (datetime.utcnow() - self.startup_time).total_seconds() if self.startup_time else 0,
                'port': self.service_port,
                'components': {}
            }
            
            # Database Health Check
            if self.database_pool:
                try:
                    async with self.database_pool.acquire() as conn:
                        start_time = datetime.utcnow()
                        await conn.execute('SELECT 1')
                        ping_time = (datetime.utcnow() - start_time).total_seconds() * 1000
                        
                        health_status['components']['database'] = {
                            'status': 'healthy',
                            'ping_ms': round(ping_time, 2),
                            'pool_size': self.database_pool.get_size(),
                            'idle_connections': self.database_pool.get_idle_size()
                        }
                except Exception as e:
                    health_status['components']['database'] = {
                        'status': 'critical',
                        'error': str(e)
                    }
                    health_status['status'] = 'warning'
            else:
                health_status['components']['database'] = {
                    'status': 'not_connected'
                }
                health_status['status'] = 'warning'
            
            # Overall health status
            component_statuses = [comp.get('status', 'unknown') for comp in health_status['components'].values()]
            if any(status == 'critical' for status in component_statuses):
                health_status['status'] = 'critical'
                self.is_healthy = False
            elif any(status in ['warning', 'not_connected'] for status in component_statuses):
                health_status['status'] = 'warning'
                self.is_healthy = True
            else:
                health_status['status'] = 'healthy'
                self.is_healthy = True
            
            return health_status
            
        except Exception as e:
            logger.error(f"Health check failed: {str(e)}")
            self.is_healthy = False
            return {
                'service': 'ml-analytics',
                'status': 'critical',
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    async def graceful_shutdown(self):
        """Graceful Service Shutdown"""
        try:
            logger.info("Starting graceful shutdown...")
            self.shutdown_requested = True
            
            # Stop accepting new requests
            if self.app:
                logger.info("Stopping FastAPI application...")
            
            # Close database pool
            if self.database_pool:
                await self.database_pool.close()
                logger.info("Database pool closed")
            
            logger.info("Graceful shutdown completed")
            
        except Exception as e:
            logger.error(f"Error during shutdown: {str(e)}")


# Global service instance
ml_service = MLAnalyticsService()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """FastAPI Lifespan Manager"""
    # Startup
    try:
        logger.info("Starting ML Analytics Service...")
        ml_service.startup_time = datetime.utcnow()
        
        await ml_service.initialize_components()
        await ml_service.setup_event_handlers()
        
        logger.info(f"ML Analytics Service started successfully on port {ML_SERVICE_CONFIG['service']['port']}")
        yield
        
    except Exception as e:
        logger.error(f"Failed to start service: {str(e)}")
        raise
    
    # Shutdown
    finally:
        await ml_service.graceful_shutdown()


# FastAPI Application
app = FastAPI(
    title="ML Analytics Service",
    description="Machine Learning Analytics Service für aktienanalyse-ökosystem",
    version="1.0.0",
    lifespan=lifespan
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8080", "https://10.1.1.174"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health Check Endpoint
@app.get("/health")
async def health_endpoint():
    """Service Health Check"""
    return await ml_service.health_check()

# ML API endpoints
@app.get("/api/v1/status")
async def get_ml_status():
    """Get ML service status"""
    return {"status": "active", "service": "ml-analytics", "version": "1.0.0"}

@app.get("/api/v1/schema/info")
async def get_ml_schema_info():
    """Get ML database schema information"""
    try:
        if not ml_service.database_pool:
            raise HTTPException(status_code=503, detail="Database not connected")
        
        async with ml_service.database_pool.acquire() as conn:
            # Get ML tables
            ml_tables = await conn.fetch("""
                SELECT table_name, 
                       (SELECT COUNT(*) FROM information_schema.columns 
                        WHERE table_name = t.table_name) as column_count
                FROM information_schema.tables t
                WHERE table_schema = 'public' AND table_name LIKE 'ml_%'
                ORDER BY table_name
            """)
            
            # Get schema version
            try:
                schema_version = await conn.fetchrow(
                    "SELECT version, deployed_at FROM ml_schema_version ORDER BY deployed_at DESC LIMIT 1"
                )
            except:
                schema_version = None
            
            return {
                "ml_tables": [dict(row) for row in ml_tables],
                "tables_count": len(ml_tables),
                "schema_version": dict(schema_version) if schema_version else None,
                "database_connected": True
            }
            
    except Exception as e:
        logger.error(f"Failed to get ML schema info: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/models/status")
async def get_models_status():
    """Get ML models status"""
    try:
        if not ml_service.database_pool:
            raise HTTPException(status_code=503, detail="Database not connected")
        
        async with ml_service.database_pool.acquire() as conn:
            # Get model registry info
            models = await conn.fetch("""
                SELECT model_type, horizon_days, version, status, 
                       performance_score, created_at, last_updated
                FROM ml_model_registry
                WHERE status = 'active'
                ORDER BY model_type, horizon_days
            """)
            
            return {
                "active_models": [dict(row) for row in models],
                "models_count": len(models),
                "timestamp": datetime.utcnow().isoformat()
            }
            
    except Exception as e:
        logger.error(f"Failed to get models status: {str(e)}")
        # Return empty result if table doesn't exist yet
        return {
            "active_models": [],
            "models_count": 0,
            "message": "No models registered yet",
            "timestamp": datetime.utcnow().isoformat()
        }

@app.get("/api/v1/predictions/{symbol}")
async def get_predictions(symbol: str):
    """Get latest predictions for symbol"""
    try:
        if not ml_service.database_pool:
            raise HTTPException(status_code=503, detail="Database not connected")
        
        symbol = symbol.upper()
        
        async with ml_service.database_pool.acquire() as conn:
            # Get latest predictions
            predictions = await conn.fetch("""
                SELECT model_type, horizon_days, predicted_value, 
                       confidence_score, prediction_timestamp
                FROM ml_predictions
                WHERE symbol = $1 
                AND prediction_timestamp >= NOW() - INTERVAL '24 hours'
                ORDER BY prediction_timestamp DESC
                LIMIT 20
            """, symbol)
            
            return {
                "symbol": symbol,
                "predictions": [dict(row) for row in predictions],
                "predictions_count": len(predictions),
                "timestamp": datetime.utcnow().isoformat()
            }
            
    except Exception as e:
        logger.error(f"Failed to get predictions for {symbol}: {str(e)}")
        # Return empty result if table doesn't exist yet
        return {
            "symbol": symbol,
            "predictions": [],
            "predictions_count": 0,
            "message": "No predictions available yet",
            "timestamp": datetime.utcnow().isoformat()
        }

@app.post("/api/v1/features/calculate/{symbol}")
async def calculate_features(symbol: str):
    """Calculate features for symbol (placeholder for ML pipeline trigger)"""
    try:
        symbol = symbol.upper()
        
        # For now, just log the request
        logger.info(f"Feature calculation requested for {symbol}")
        
        return {
            "symbol": symbol,
            "status": "accepted",
            "message": "Feature calculation request accepted - implementation pending",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to calculate features for {symbol}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Store app reference
ml_service.app = app


def signal_handler(signum, frame):
    """Signal Handler for Graceful Shutdown"""
    logger.info(f"Received signal {signum}, initiating graceful shutdown...")
    asyncio.create_task(ml_service.graceful_shutdown())
    sys.exit(0)


if __name__ == "__main__":
    # Signal Handlers
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        # Start Service
        uvicorn.run(
            "ml_analytics_orchestrator_v1_0_0_20250817:app",
            host=ML_SERVICE_CONFIG['service']['host'],
            port=ML_SERVICE_CONFIG['service']['port'],
            workers=1,  # Single worker für ML-Service
            log_level="info",
            access_log=True,
            reload=False
        )
        
    except Exception as e:
        logger.error(f"Failed to start ML Analytics Service: {str(e)}")
        sys.exit(1)