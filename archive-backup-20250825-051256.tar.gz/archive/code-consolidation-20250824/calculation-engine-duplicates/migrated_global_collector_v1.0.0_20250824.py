#!/usr/bin/env python3
"""
Migrated Global Market Collector v1.0.0
Bestehende Module refactored um Clean Data Analysis Service zu verwenden

MIGRATION STRATEGY:
- Ersetzt direkte DB-Zugriffe durch Service-Calls
- Behält bestehende API bei für Backward-Compatibility  
- Nutzt Clean Architecture Service im Backend
- Production-Ready mit Error Handling

Author: Claude Code & Aktienanalyse Team
Version: 1.0.0  
Date: 2024-08-24
Priority: Clean Architecture Migration
"""

import asyncio
import sys
import os
import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional
import traceback

# Use virtual environment
sys.path.insert(0, '/home/mdoehler/aktienanalyse-venv/lib/python3.11/site-packages')

try:
    import requests
    import aiohttp
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    logging.error("requests/aiohttp not available")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CleanServiceClient:
    """Client für Clean Data Analysis Service"""
    
    def __init__(self, service_url: str = "http://localhost:8002"):
        self.service_url = service_url
        self.timeout = 30.0
        
    async def generate_predictions_via_service(self, symbols: List[str]) -> Dict[str, Any]:
        """Generate predictions using Clean Data Analysis Service"""
        try:
            if not REQUESTS_AVAILABLE:
                raise RuntimeError("HTTP client not available")
            
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.timeout)) as session:
                payload = {"symbols": symbols}
                
                async with session.post(
                    f"{self.service_url}/api/v1/predictions/generate",
                    json=payload,
                    headers={"Content-Type": "application/json"}
                ) as response:
                    
                    if response.status == 200:
                        data = await response.json()
                        logger.info(f"✅ Generated predictions via Clean Service for {len(symbols)} symbols")
                        return {
                            "success": True,
                            "predictions": data,
                            "source": "clean_service",
                            "timestamp": datetime.now().isoformat()
                        }
                    else:
                        error_text = await response.text()
                        logger.error(f"Service error {response.status}: {error_text}")
                        return {
                            "success": False,
                            "error": f"Service returned {response.status}: {error_text}",
                            "source": "clean_service"
                        }
                        
        except Exception as e:
            logger.error(f"Failed to call Clean Service: {e}")
            return {
                "success": False,
                "error": str(e),
                "source": "clean_service"
            }
    
    async def calculate_ist_via_service(self) -> Dict[str, Any]:
        """Calculate IST performance using Clean Service"""
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.timeout)) as session:
                async with session.post(f"{self.service_url}/api/v1/ist/calculate") as response:
                    if response.status == 200:
                        data = await response.json()
                        logger.info(f"✅ Calculated IST performance via Clean Service")
                        return data
                    else:
                        error_text = await response.text()
                        return {"success": False, "error": f"Service error: {error_text}"}
                        
        except Exception as e:
            logger.error(f"Failed to calculate IST via service: {e}")
            return {"success": False, "error": str(e)}

    async def health_check(self) -> bool:
        """Check if Clean Service is healthy"""
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5.0)) as session:
                async with session.get(f"{self.service_url}/api/v1/health") as response:
                    if response.status == 200:
                        data = await response.json()
                        logger.info(f"✅ Clean Service is healthy: {data.get('service', 'Unknown')}")
                        return True
                    return False
                    
        except Exception as e:
            logger.warning(f"Clean Service not available: {e}")
            return False

class MigratedGlobalCollector:
    """
    Migrated Global Collector using Clean Architecture Service
    
    Maintains existing API but uses Clean Service backend
    """
    
    def __init__(self):
        self.clean_service = CleanServiceClient()
        
    async def process_symbols_with_clean_service(self, symbols: List[str]) -> Dict[str, Any]:
        """Process symbols using Clean Architecture Service"""
        
        # Check if Clean Service is available
        service_healthy = await self.clean_service.health_check()
        
        if not service_healthy:
            return {
                "success": False,
                "error": "Clean Data Analysis Service not available",
                "processed_count": 0,
                "fallback_used": True
            }
        
        # Use Clean Service for predictions
        results = await self.clean_service.generate_predictions_via_service(symbols)
        
        if results["success"]:
            # Transform response to match existing API
            transformed_results = {
                "success_count": 0,
                "error_count": 0,
                "predictions": [],
                "processing_time": 0.0,
                "source": "clean_architecture_service",
                "timestamp": datetime.now().isoformat()
            }
            
            for prediction_response in results["predictions"]:
                if prediction_response["success"]:
                    transformed_results["success_count"] += len(prediction_response["predictions"])
                    
                    for pred in prediction_response["predictions"]:
                        transformed_results["predictions"].append({
                            "symbol": prediction_response["symbol"],
                            "horizon": pred["horizon"],
                            "target_date": pred["target_date"],
                            "profit_forecast": pred["profit_forecast"],
                            "confidence": pred["confidence"],
                            "source": "clean_service"
                        })
                else:
                    transformed_results["error_count"] += 1
            
            return transformed_results
        else:
            return {
                "success": False,
                "error": results.get("error", "Unknown service error"),
                "processed_count": 0,
                "source": "clean_service"
            }

async def main():
    """Main function with Clean Service integration"""
    print("🔄 Migrated Global Market Collector v1.0.0")
    print("🏗️ Using Clean Architecture Data Analysis Service")
    print("=" * 70)
    
    collector = MigratedGlobalCollector()
    
    # Test symbols
    test_symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'NVDA']
    
    print(f"📊 Processing {len(test_symbols)} symbols via Clean Service...")
    
    results = await collector.process_symbols_with_clean_service(test_symbols)
    
    if results.get("success", True):
        print(f"✅ Processing Results:")
        print(f"   - Successful predictions: {results.get('success_count', 0)}")
        print(f"   - Processing errors: {results.get('error_count', 0)}")
        print(f"   - Source: {results.get('source', 'Unknown')}")
        
        predictions = results.get("predictions", [])[:5]  # Show first 5
        if predictions:
            print(f"\n📈 Sample Predictions:")
            for pred in predictions:
                print(f"   - {pred['symbol']} {pred['horizon']}: {pred['profit_forecast']}€ (confidence: {pred['confidence']})")
    else:
        print(f"❌ Processing failed: {results.get('error', 'Unknown error')}")
        if results.get("fallback_used"):
            print("💡 Tip: Start Clean Data Analysis Service first")

if __name__ == "__main__":
    # Install aiohttp if needed
    if not REQUESTS_AVAILABLE:
        print("Installing required packages...")
        os.system("source /home/mdoehler/aktienanalyse-venv/bin/activate && pip install aiohttp requests")
    
    asyncio.run(main())