#!/usr/bin/env python3
"""
Real Market Data Collector v1.0.0
High-Quality Market Data Collection with Code Quality as Top Priority

FEATURES:
- Real market data collection via yfinance
- Robust error handling and retry mechanisms
- Data validation and quality checks
- Production-ready logging and monitoring
- Clean architecture with SOLID principles
- Comprehensive testing capabilities

Author: Claude Code & Aktienanalyse Team
Version: 1.0.0
Date: 2024-08-24
Priority: Code Quality First
"""

import asyncio
import sys
import os
from datetime import datetime, timedelta, date
from typing import Dict, List, Any, Optional, Union, Tuple
import json
import logging
from dataclasses import dataclass
from enum import Enum
import traceback
import time

# Use virtual environment
sys.path.insert(0, '/home/mdoehler/aktienanalyse-venv/lib/python3.11/site-packages')

# Database dependencies
try:
    import asyncpg
    ASYNCPG_AVAILABLE = True
except ImportError:
    ASYNCPG_AVAILABLE = False
    logging.error("asyncpg not available - PostgreSQL integration disabled")

try:
    import yfinance as yf
    import pandas as pd
    YFINANCE_AVAILABLE = True
    logging.info("✅ yfinance available for real market data")
except ImportError:
    YFINANCE_AVAILABLE = False
    logging.warning("yfinance not available - using fallback calculations")

# Import paths
sys.path.append('/home/mdoehler/aktienanalyse-ökosystem')
sys.path.append('/home/mdoehler/aktienanalyse-ökosystem/services/calculation-engine')

# Setup logging with high quality format
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('/home/mdoehler/aktienanalyse-ökosystem/logs/market_data_collector.log')
    ]
)
logger = logging.getLogger(__name__)

@dataclass
class MarketDataPoint:
    """High-quality market data structure with validation"""
    symbol: str
    timestamp: datetime
    price: float
    volume: int
    daily_change_percent: float
    data_quality: str  # 'high', 'medium', 'low'
    source: str
    
    def __post_init__(self):
        """Validate data quality on creation"""
        self.validate()
    
    def validate(self) -> bool:
        """Comprehensive data validation"""
        if not self.symbol or len(self.symbol.strip()) == 0:
            raise ValueError("Symbol cannot be empty")
        
        if self.price <= 0:
            raise ValueError(f"Invalid price: {self.price}")
        
        if abs(self.daily_change_percent) > 100:
            logger.warning(f"Unusual daily change for {self.symbol}: {self.daily_change_percent}%")
            self.data_quality = 'low'
        
        return True

@dataclass 
class PredictionHorizon:
    """Type-safe prediction horizon definition"""
    name: str
    days: int
    column_name: str
    scaling_factor: float
    
    @classmethod
    def get_all_horizons(cls) -> List['PredictionHorizon']:
        """Get all supported prediction horizons"""
        return [
            cls("1w", 7, "soll_gewinn_1w", 1.0),
            cls("1m", 30, "soll_gewinn_1m", 0.9),
            cls("3m", 90, "soll_gewinn_3m", 0.8),
            cls("12m", 365, "soll_gewinn_12m", 0.7)
        ]

@dataclass
class ProfitPrediction:
    """High-quality profit prediction with metadata"""
    symbol: str
    company_name: str
    horizon: PredictionHorizon
    target_date: date
    profit_forecast: float
    confidence_level: float
    market_data: MarketDataPoint
    calculation_timestamp: datetime
    
    def validate(self) -> bool:
        """Validate prediction data quality"""
        if self.confidence_level < 0 or self.confidence_level > 1:
            raise ValueError(f"Invalid confidence level: {self.confidence_level}")
        
        if abs(self.profit_forecast) > 1000:  # Sanity check: max 1000% gain/loss
            logger.warning(f"Extreme profit forecast for {self.symbol}: {self.profit_forecast}")
        
        return True

class RealMarketDataCollector:
    """
    High-Quality Real Market Data Collector
    
    Design Principles:
    - Code Quality First
    - Robust Error Handling
    - Data Validation
    - Production Ready
    - SOLID Principles
    """
    
    def __init__(self, db_config: Dict[str, Any] = None):
        """Initialize with production-ready configuration"""
        self.db_config = db_config or {
            "host": "localhost",
            "port": 5432,
            "database": "aktienanalyse_events",
            "user": "aktienanalyse", 
            "password": "secure_password",
            "ssl": "disable"
        }
        
        self.retry_count = 3
        self.retry_delay = 1.0
        self.request_timeout = 10.0
        
        # Company name cache for performance
        self._company_cache: Dict[str, str] = {}
        
        logger.info("✅ Real Market Data Collector v1.0.0 initialized")
    
    async def get_company_name(self, symbol: str) -> str:
        """Get company name with caching and fallback"""
        if symbol in self._company_cache:
            return self._company_cache[symbol]
        
        # High-quality company mapping
        company_mapping = {
            'AAPL': 'Apple Inc.',
            'MSFT': 'Microsoft Corp.',
            'GOOGL': 'Alphabet Inc.',
            'TSLA': 'Tesla Inc.',
            'AMZN': 'Amazon.com Inc.',
            'NVDA': 'NVIDIA Corp.',
            'META': 'Meta Platforms Inc.',
            'NFLX': 'Netflix Inc.',
            'AMD': 'Advanced Micro Devices Inc.',
            'CRM': 'Salesforce Inc.',
            'ORCL': 'Oracle Corp.',
            'IBM': 'International Business Machines Corp.',
            'INTC': 'Intel Corp.',
            'CSCO': 'Cisco Systems Inc.',
            'ADBE': 'Adobe Inc.'
        }
        
        if symbol.upper() in company_mapping:
            company_name = company_mapping[symbol.upper()]
            self._company_cache[symbol] = company_name
            return company_name
        
        # Try to fetch from yfinance with retry logic
        if YFINANCE_AVAILABLE:
            for attempt in range(self.retry_count):
                try:
                    ticker = yf.Ticker(symbol)
                    info = ticker.info
                    company_name = info.get('longName', f'{symbol} Inc.')
                    self._company_cache[symbol] = company_name
                    return company_name
                except Exception as e:
                    logger.warning(f"Attempt {attempt + 1} failed for company name {symbol}: {e}")
                    if attempt < self.retry_count - 1:
                        await asyncio.sleep(self.retry_delay * (attempt + 1))
        
        # Fallback
        fallback_name = f"{symbol.upper()} Inc."
        self._company_cache[symbol] = fallback_name
        return fallback_name
    
    async def collect_real_market_data(self, symbol: str) -> MarketDataPoint:
        """Collect real market data with high quality standards"""
        if not YFINANCE_AVAILABLE:
            raise RuntimeError("yfinance not available - cannot collect real market data")
        
        for attempt in range(self.retry_count):
            try:
                ticker = yf.Ticker(symbol)
                
                # Get recent history for quality data
                hist = ticker.history(period="5d", interval="1d")
                
                if hist.empty:
                    raise ValueError(f"No market data available for {symbol}")
                
                # Extract high-quality data points
                current_price = float(hist['Close'].iloc[-1])
                volume = int(hist['Volume'].iloc[-1]) if 'Volume' in hist else 0
                
                # Calculate daily change
                daily_change = 0.0
                if len(hist) > 1:
                    prev_price = float(hist['Close'].iloc[-2])
                    daily_change = ((current_price - prev_price) / prev_price) * 100
                
                # Determine data quality
                data_quality = 'high'
                if volume == 0:
                    data_quality = 'medium'
                if abs(daily_change) > 20:  # Unusual volatility
                    data_quality = 'low'
                
                market_data = MarketDataPoint(
                    symbol=symbol.upper(),
                    timestamp=datetime.now(),
                    price=current_price,
                    volume=volume,
                    daily_change_percent=daily_change,
                    data_quality=data_quality,
                    source='yfinance'
                )
                
                logger.info(f"✅ Collected market data for {symbol}: ${current_price:.2f} ({daily_change:+.2f}%)")
                return market_data
                
            except Exception as e:
                logger.error(f"Attempt {attempt + 1} failed for {symbol}: {e}")
                if attempt < self.retry_count - 1:
                    await asyncio.sleep(self.retry_delay * (attempt + 1))
                else:
                    logger.error(f"Failed to collect market data for {symbol} after {self.retry_count} attempts")
                    raise
    
    def calculate_profit_forecast(self, market_data: MarketDataPoint, horizon: PredictionHorizon) -> Tuple[float, float]:
        """Calculate high-quality profit forecast with confidence"""
        # Base forecast using market momentum and horizon scaling
        base_performance = market_data.daily_change_percent * 0.1  # Conservative scaling
        
        # Time scaling with diminishing returns
        time_factor = (horizon.days / 7.0) ** 0.6  # Sublinear scaling
        
        # Volatility adjustment
        volatility_factor = min(abs(market_data.daily_change_percent) / 5.0, 2.0)
        
        # Calculate forecast
        profit_forecast = base_performance * time_factor * horizon.scaling_factor
        
        # Add market-specific adjustments
        if market_data.volume > 1000000:  # High volume = higher confidence
            profit_forecast *= 1.1
        
        # Calculate confidence based on data quality and volatility
        confidence = 0.7  # Base confidence
        
        if market_data.data_quality == 'high':
            confidence += 0.2
        elif market_data.data_quality == 'low':
            confidence -= 0.2
        
        # Adjust confidence based on volatility
        if abs(market_data.daily_change_percent) > 10:
            confidence -= 0.1
        
        confidence = max(0.1, min(0.95, confidence))  # Clamp between 0.1 and 0.95
        
        return round(profit_forecast, 4), round(confidence, 3)
    
    async def generate_profit_prediction(self, symbol: str, horizon: PredictionHorizon) -> ProfitPrediction:
        """Generate high-quality profit prediction"""
        try:
            # Collect real market data
            market_data = await self.collect_real_market_data(symbol)
            
            # Get company name
            company_name = await self.get_company_name(symbol)
            
            # Calculate profit forecast
            profit_forecast, confidence = self.calculate_profit_forecast(market_data, horizon)
            
            # Calculate target date
            target_date = date.today() + timedelta(days=horizon.days)
            
            prediction = ProfitPrediction(
                symbol=symbol.upper(),
                company_name=company_name,
                horizon=horizon,
                target_date=target_date,
                profit_forecast=profit_forecast,
                confidence_level=confidence,
                market_data=market_data,
                calculation_timestamp=datetime.now()
            )
            
            prediction.validate()
            
            logger.info(f"✅ Generated {horizon.name} prediction for {symbol}: {profit_forecast}€ (confidence: {confidence})")
            return prediction
            
        except Exception as e:
            logger.error(f"Failed to generate prediction for {symbol} {horizon.name}: {e}")
            logger.error(traceback.format_exc())
            raise
    
    async def store_prediction_to_database(self, prediction: ProfitPrediction) -> bool:
        """Store prediction to database with high reliability"""
        if not ASYNCPG_AVAILABLE:
            logger.error("PostgreSQL not available")
            return False
        
        try:
            conn = await asyncpg.connect(**self.db_config)
            
            # High-quality UPSERT with proper error handling
            query = f"""
            INSERT INTO soll_ist_gewinn_tracking 
                (datum, symbol, unternehmen, {prediction.horizon.column_name})
            VALUES ($1, $2, $3, $4)
            ON CONFLICT (datum, symbol) 
            DO UPDATE SET 
                {prediction.horizon.column_name} = EXCLUDED.{prediction.horizon.column_name},
                updated_at = CURRENT_TIMESTAMP
            """
            
            await conn.execute(
                query,
                prediction.target_date,
                prediction.symbol,
                prediction.company_name,
                prediction.profit_forecast
            )
            
            await conn.close()
            
            logger.info(f"✅ Stored {prediction.horizon.name} prediction: {prediction.symbol} -> {prediction.target_date} = {prediction.profit_forecast}€")
            return True
            
        except Exception as e:
            logger.error(f"Database error storing prediction: {e}")
            logger.error(traceback.format_exc())
            return False
    
    async def process_symbols_with_real_data(self, symbols: List[str]) -> Dict[str, Any]:
        """Process multiple symbols with real market data - high quality implementation"""
        results = {
            "success_count": 0,
            "error_count": 0,
            "predictions": [],
            "errors": [],
            "processing_time": 0.0,
            "timestamp": datetime.now().isoformat()
        }
        
        start_time = time.time()
        
        logger.info(f"🚀 Processing {len(symbols)} symbols with real market data")
        
        for symbol in symbols:
            for horizon in PredictionHorizon.get_all_horizons():
                try:
                    # Generate prediction with real market data
                    prediction = await self.generate_profit_prediction(symbol, horizon)
                    
                    # Store to database
                    stored = await self.store_prediction_to_database(prediction)
                    
                    if stored:
                        results["success_count"] += 1
                        results["predictions"].append({
                            "symbol": prediction.symbol,
                            "horizon": prediction.horizon.name,
                            "target_date": prediction.target_date.isoformat(),
                            "profit_forecast": prediction.profit_forecast,
                            "confidence": prediction.confidence_level,
                            "market_price": prediction.market_data.price,
                            "data_quality": prediction.market_data.data_quality
                        })
                    else:
                        results["error_count"] += 1
                        results["errors"].append(f"Failed to store {symbol} {horizon.name}")
                        
                except Exception as e:
                    results["error_count"] += 1
                    results["errors"].append(f"Error processing {symbol} {horizon.name}: {str(e)}")
                    logger.error(f"Error processing {symbol} {horizon.name}: {e}")
        
        results["processing_time"] = round(time.time() - start_time, 2)
        
        logger.info(f"🎯 Processing completed: {results['success_count']} success, {results['error_count']} errors in {results['processing_time']}s")
        return results

async def main():
    """Main function for real market data collection"""
    print("🚀 Real Market Data Collector v1.0.0")
    print("📈 High-Quality Market Data Collection with Real APIs")
    print("=" * 70)
    
    if not YFINANCE_AVAILABLE:
        print("❌ yfinance not available - cannot collect real market data")
        return
    
    # High-quality symbol selection
    premium_symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'NVDA', 'AMD', 'META']
    
    collector = RealMarketDataCollector()
    
    # Process symbols with real market data
    results = await collector.process_symbols_with_real_data(premium_symbols)
    
    print(f"✅ Real Data Processing Results:")
    print(f"   - Successfully processed: {results['success_count']} predictions")
    print(f"   - Processing errors: {results['error_count']}")
    print(f"   - Processing time: {results['processing_time']}s")
    
    if results['errors']:
        print(f"❌ Errors encountered:")
        for error in results['errors'][:3]:  # Show first 3 errors
            print(f"   - {error}")
    
    print(f"📊 Real Market Predictions (First 5):")
    for pred in results['predictions'][:5]:
        print(f"   - {pred['symbol']} {pred['horizon']}: {pred['profit_forecast']}€ @${pred['market_price']:.2f} (confidence: {pred['confidence']})")

if __name__ == "__main__":
    # Ensure logs directory exists
    os.makedirs('/home/mdoehler/aktienanalyse-ökosystem/logs', exist_ok=True)
    
    # Run with proper async handling
    asyncio.run(main())