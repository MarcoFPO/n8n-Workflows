#!/usr/bin/env python3
"""
Profit Tracking Integration v3.1.0
Integriert Unified Profit Engine mit Multi-Horizon SOLL-IST Gewinn-Tracking Tabelle

FEATURES:
- Automatische Vorhersagen für 1W, 1M, 3M, 12M Horizonte
- PostgreSQL Integration für SOLL-IST Tabelle
- Unified Profit Engine Integration
- Event-basierte Aktualisierungen
- Comprehensive Error Handling

Author: Claude Code & Aktienanalyse Team
Version: 3.1.0
Date: 2024-08-24
"""

import asyncio
import sys
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Union, Tuple
import json
import logging
from dataclasses import dataclass
from enum import Enum

# Database dependencies
try:
    import asyncpg
    ASYNCPG_AVAILABLE = True
except ImportError:
    ASYNCPG_AVAILABLE = False
    logging.error("asyncpg not available - PostgreSQL integration disabled")

try:
    import yfinance as yf
    YFINANCE_AVAILABLE = True
except ImportError:
    YFINANCE_AVAILABLE = False
    logging.warning("yfinance not available")

# Import paths
sys.path.append('/home/mdoehler/aktienanalyse-ökosystem')
sys.path.append('/home/mdoehler/aktienanalyse-ökosystem/services/calculation-engine')

try:
    from unified_profit_calculation_engine_v3_0_0_20250823 import UnifiedProfitCalculationEngine, EngineMode
    UPE_AVAILABLE = True
except ImportError:
    UPE_AVAILABLE = False
    logging.error("Unified Profit Engine not available")

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PredictionHorizon(Enum):
    """Prediction time horizons"""
    ONE_WEEK = "1w"
    ONE_MONTH = "1m"
    THREE_MONTHS = "3m"
    TWELVE_MONTHS = "12m"

@dataclass
class MultiHorizonPrediction:
    """Multi-horizon prediction data structure"""
    symbol: str
    unternehmen: str
    datum: datetime
    soll_gewinn_1w: Optional[float] = None
    soll_gewinn_1m: Optional[float] = None
    soll_gewinn_3m: Optional[float] = None
    soll_gewinn_12m: Optional[float] = None
    confidence_1w: Optional[float] = None
    confidence_1m: Optional[float] = None
    confidence_3m: Optional[float] = None
    confidence_12m: Optional[float] = None


class ProfitTrackingIntegrator:
    """
    Integration between Unified Profit Engine and Multi-Horizon Tracking Database
    """
    
    def __init__(self, db_config: Dict[str, Any] = None):
        """Initialize the profit tracking integrator"""
        self.db_config = db_config or {
            "host": "localhost",
            "port": 5432,
            "database": "aktienanalyse_events",
            "user": "aktienanalyse",
            "password": "secure_password",
            "ssl": "disable"
        }
        
        # Initialize Unified Profit Engine
        if UPE_AVAILABLE:
            self.profit_engine = UnifiedProfitCalculationEngine(
                mode=EngineMode.STANDALONE,
                config={"enable_yfinance": YFINANCE_AVAILABLE}
            )
        else:
            self.profit_engine = None
            logger.error("Unified Profit Engine not available")
    
    async def get_company_name_for_symbol(self, symbol: str) -> str:
        """Get company name for symbol"""
        # Common stock symbol to company name mapping
        symbol_mapping = {
            'AAPL': 'Apple Inc.',
            'MSFT': 'Microsoft Corp.',
            'GOOGL': 'Alphabet Inc.',
            'TSLA': 'Tesla Inc.',
            'AMZN': 'Amazon.com Inc.',
            'NVDA': 'NVIDIA Corp.',
            'META': 'Meta Platforms Inc.',
            'NFLX': 'Netflix Inc.',
            'AMD': 'Advanced Micro Devices Inc.',
            'CRM': 'Salesforce Inc.',
            'ORCL': 'Oracle Corp.',
            'IBM': 'International Business Machines Corp.',
            'INTC': 'Intel Corp.',
            'CSCO': 'Cisco Systems Inc.',
            'ADBE': 'Adobe Inc.'
        }
        
        if symbol.upper() in symbol_mapping:
            return symbol_mapping[symbol.upper()]
        
        # Try to get from yfinance if available
        if YFINANCE_AVAILABLE:
            try:
                ticker = yf.Ticker(symbol)
                info = ticker.info
                return info.get('longName', f'{symbol} Inc.')
            except Exception as e:
                logger.warning(f"Could not fetch company name for {symbol}: {e}")
        
        return f"{symbol} Inc."
    
    async def get_market_data_for_prediction(self, symbol: str) -> Dict[str, Any]:
        """Get current market data for profit prediction"""
        market_data = {
            'symbol': symbol,
            'timestamp': datetime.utcnow().isoformat(),
            'daily_change_percent': 0.0,
            'volume': 0,
            'price': 100.0,  # Default fallback
        }
        
        if YFINANCE_AVAILABLE:
            try:
                ticker = yf.Ticker(symbol)
                hist = ticker.history(period="5d")
                
                if not hist.empty:
                    current_price = hist['Close'].iloc[-1]
                    prev_price = hist['Close'].iloc[-2] if len(hist) > 1 else current_price
                    
                    daily_change = ((current_price - prev_price) / prev_price) * 100
                    volume = hist['Volume'].iloc[-1] if 'Volume' in hist else 0
                    
                    market_data.update({
                        'daily_change_percent': float(daily_change),
                        'volume': int(volume),
                        'price': float(current_price)
                    })
                    
            except Exception as e:
                logger.warning(f"Could not fetch market data for {symbol}: {e}")
        
        return market_data
    
    async def generate_multi_horizon_prediction(self, symbol: str) -> MultiHorizonPrediction:
        """Generate profit predictions for all time horizons"""
        company_name = await self.get_company_name_for_symbol(symbol)
        market_data = await self.get_market_data_for_prediction(symbol)
        
        # Current date for prediction base
        base_date = datetime.now().date()
        
        prediction = MultiHorizonPrediction(
            symbol=symbol.upper(),
            unternehmen=company_name,
            datum=base_date
        )
        
        if self.profit_engine:
            try:
                # Generate predictions for each horizon
                horizons = [
                    (PredictionHorizon.ONE_WEEK, 7),
                    (PredictionHorizon.ONE_MONTH, 30),
                    (PredictionHorizon.THREE_MONTHS, 90),
                    (PredictionHorizon.TWELVE_MONTHS, 365)
                ]
                
                for horizon, days in horizons:
                    # Create prediction using unified engine
                    profit_pred = await self.profit_engine.create_profit_prediction(
                        symbol=symbol,
                        company_name=company_name,
                        market_data=market_data
                    )
                    
                    # Scale prediction based on time horizon
                    base_profit = profit_pred.profit_forecast
                    time_scaling_factor = (days / 7.0) ** 0.5  # Square root scaling
                    
                    # Add some horizon-specific adjustments
                    horizon_adjustments = {
                        PredictionHorizon.ONE_WEEK: 1.0,
                        PredictionHorizon.ONE_MONTH: 0.9,   # Slightly more conservative
                        PredictionHorizon.THREE_MONTHS: 0.8,  # More conservative
                        PredictionHorizon.TWELVE_MONTHS: 0.7   # Most conservative
                    }
                    
                    adjusted_profit = base_profit * time_scaling_factor * horizon_adjustments[horizon]
                    
                    # Store predictions based on horizon
                    if horizon == PredictionHorizon.ONE_WEEK:
                        prediction.soll_gewinn_1w = round(adjusted_profit, 4)
                        prediction.confidence_1w = profit_pred.confidence_level
                    elif horizon == PredictionHorizon.ONE_MONTH:
                        prediction.soll_gewinn_1m = round(adjusted_profit, 4)
                        prediction.confidence_1m = profit_pred.confidence_level
                    elif horizon == PredictionHorizon.THREE_MONTHS:
                        prediction.soll_gewinn_3m = round(adjusted_profit, 4)
                        prediction.confidence_3m = profit_pred.confidence_level
                    elif horizon == PredictionHorizon.TWELVE_MONTHS:
                        prediction.soll_gewinn_12m = round(adjusted_profit, 4)
                        prediction.confidence_12m = profit_pred.confidence_level
                        
            except Exception as e:
                logger.error(f"Error generating predictions for {symbol}: {e}")
                # Fallback to simple predictions
                prediction.soll_gewinn_1w = 1.0
                prediction.soll_gewinn_1m = 1.2
                prediction.soll_gewinn_3m = 1.5
                prediction.soll_gewinn_12m = 2.0
        else:
            # Fallback predictions if engine not available
            logger.warning("Using fallback predictions - Unified Profit Engine not available")
            prediction.soll_gewinn_1w = 1.0
            prediction.soll_gewinn_1m = 1.2
            prediction.soll_gewinn_3m = 1.5
            prediction.soll_gewinn_12m = 2.0
        
        return prediction
    
    async def store_prediction_in_tracking_table(self, prediction: MultiHorizonPrediction) -> bool:
        """Store multi-horizon prediction in PostgreSQL tracking table"""
        if not ASYNCPG_AVAILABLE:
            logger.error("PostgreSQL not available")
            return False
        
        try:
            conn = await asyncpg.connect(**self.db_config)
            
            # Insert or update prediction
            query = """
            INSERT INTO soll_ist_gewinn_tracking 
                (datum, symbol, unternehmen, soll_gewinn_1w, soll_gewinn_1m, soll_gewinn_3m, soll_gewinn_12m)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            ON CONFLICT (datum, symbol) 
            DO UPDATE SET 
                soll_gewinn_1w = EXCLUDED.soll_gewinn_1w,
                soll_gewinn_1m = EXCLUDED.soll_gewinn_1m,
                soll_gewinn_3m = EXCLUDED.soll_gewinn_3m,
                soll_gewinn_12m = EXCLUDED.soll_gewinn_12m,
                updated_at = CURRENT_TIMESTAMP
            """
            
            await conn.execute(
                query,
                prediction.datum,
                prediction.symbol,
                prediction.unternehmen,
                prediction.soll_gewinn_1w,
                prediction.soll_gewinn_1m,
                prediction.soll_gewinn_3m,
                prediction.soll_gewinn_12m
            )
            
            await conn.close()
            logger.info(f"Successfully stored prediction for {prediction.symbol} on {prediction.datum}")
            return True
            
        except Exception as e:
            logger.error(f"Error storing prediction in tracking table: {e}")
            return False
    
    async def create_unique_constraint_if_missing(self):
        """Create unique constraint on datum+symbol if it doesn't exist"""
        if not ASYNCPG_AVAILABLE:
            return False
            
        try:
            conn = await asyncpg.connect(**self.db_config)
            
            # Check if constraint exists
            constraint_exists = await conn.fetchval("""
                SELECT 1 FROM information_schema.table_constraints 
                WHERE constraint_name = 'soll_ist_gewinn_tracking_datum_symbol_key'
                AND table_name = 'soll_ist_gewinn_tracking'
            """)
            
            if not constraint_exists:
                # Add unique constraint
                await conn.execute("""
                    ALTER TABLE soll_ist_gewinn_tracking 
                    ADD CONSTRAINT soll_ist_gewinn_tracking_datum_symbol_key 
                    UNIQUE (datum, symbol)
                """)
                logger.info("Added unique constraint on (datum, symbol)")
            
            await conn.close()
            return True
            
        except Exception as e:
            logger.error(f"Error creating unique constraint: {e}")
            return False
    
    async def generate_predictions_for_symbols(self, symbols: List[str]) -> List[MultiHorizonPrediction]:
        """Generate predictions for multiple symbols"""
        predictions = []
        
        for symbol in symbols:
            try:
                prediction = await self.generate_multi_horizon_prediction(symbol)
                predictions.append(prediction)
                logger.info(f"Generated prediction for {symbol}")
            except Exception as e:
                logger.error(f"Error generating prediction for {symbol}: {e}")
        
        return predictions
    
    async def update_tracking_table_with_predictions(self, symbols: List[str]) -> Dict[str, Any]:
        """Complete workflow: Generate predictions and store in tracking table"""
        results = {
            "success_count": 0,
            "error_count": 0,
            "predictions": [],
            "errors": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Ensure unique constraint exists
        await self.create_unique_constraint_if_missing()
        
        # Generate predictions
        predictions = await self.generate_predictions_for_symbols(symbols)
        
        # Store predictions
        for prediction in predictions:
            try:
                success = await self.store_prediction_in_tracking_table(prediction)
                if success:
                    results["success_count"] += 1
                    results["predictions"].append({
                        "symbol": prediction.symbol,
                        "datum": prediction.datum.isoformat(),
                        "soll_gewinn_1w": prediction.soll_gewinn_1w,
                        "soll_gewinn_1m": prediction.soll_gewinn_1m,
                        "soll_gewinn_3m": prediction.soll_gewinn_3m,
                        "soll_gewinn_12m": prediction.soll_gewinn_12m
                    })
                else:
                    results["error_count"] += 1
                    results["errors"].append(f"Failed to store prediction for {prediction.symbol}")
            except Exception as e:
                results["error_count"] += 1
                results["errors"].append(f"Error processing {prediction.symbol}: {str(e)}")
        
        logger.info(f"Prediction update completed: {results['success_count']} success, {results['error_count']} errors")
        return results


async def main():
    """Main function for testing and standalone execution"""
    print("🚀 Profit Tracking Integration v3.1.0")
    print("=" * 60)
    
    # Test symbols
    test_symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'AMZN']
    
    # Initialize integrator
    integrator = ProfitTrackingIntegrator()
    
    # Run integration
    results = await integrator.update_tracking_table_with_predictions(test_symbols)
    
    print(f"✅ Processing completed:")
    print(f"   - Successful predictions: {results['success_count']}")
    print(f"   - Errors: {results['error_count']}")
    
    if results['errors']:
        print(f"❌ Errors:")
        for error in results['errors']:
            print(f"   - {error}")
    
    if results['predictions']:
        print(f"📊 Generated predictions:")
        for pred in results['predictions'][:3]:  # Show first 3
            print(f"   - {pred['symbol']}: 1W={pred['soll_gewinn_1w']}€, 1M={pred['soll_gewinn_1m']}€, 3M={pred['soll_gewinn_3m']}€, 12M={pred['soll_gewinn_12m']}€")


if __name__ == "__main__":
    asyncio.run(main())