#!/usr/bin/env python3
"""
Multi-Horizon Profit Tracker v3.2.0
Erweiterte Integration für alle Zeithorizonte mit separaten Datensätzen und berechneten Zieldaten

NEUE FEATURES v3.2.0:
- Separate Datensätze für jeden Zeithorizont (1W, 1M, 3M, 12M)
- Zieldatum-Berechnung: heute + Zeitraum
- Vorhersage wird im entsprechenden Zieldatum-Datensatz gespeichert
- Multi-Horizon Database Integration mit Datum-basierten Einträgen

BEISPIEL ERGEBNIS:
- Datum: 2024-08-24, Symbol: AAPL, soll_gewinn_1w: 2.10€, andere Spalten: NULL
- Datum: 2024-08-31, Symbol: AAPL, soll_gewinn_1w: NULL, soll_gewinn_1m: 2.30€, andere: NULL  
- Datum: 2024-09-24, Symbol: AAPL, soll_gewinn_3m: 2.60€, andere: NULL
- Datum: 2025-08-24, Symbol: AAPL, soll_gewinn_12m: 3.20€, andere: NULL

Author: Claude Code & Aktienanalyse Team
Version: 3.2.0
Date: 2024-08-24
"""

import asyncio
import sys
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Union, Tuple
import json
import logging
from dataclasses import dataclass
from enum import Enum

# Database dependencies
try:
    import asyncpg
    ASYNCPG_AVAILABLE = True
except ImportError:
    ASYNCPG_AVAILABLE = False
    logging.error("asyncpg not available - PostgreSQL integration disabled")

try:
    import yfinance as yf
    YFINANCE_AVAILABLE = True
except ImportError:
    YFINANCE_AVAILABLE = False
    logging.warning("yfinance not available")

# Import paths
sys.path.append('/home/mdoehler/aktienanalyse-ökosystem')
sys.path.append('/home/mdoehler/aktienanalyse-ökosystem/services/calculation-engine')

try:
    from unified_profit_calculation_engine_v3_0_0_20250823 import UnifiedProfitCalculationEngine, EngineMode
    UPE_AVAILABLE = True
except ImportError:
    UPE_AVAILABLE = False
    logging.error("Unified Profit Engine not available")

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PredictionHorizon(Enum):
    """Prediction time horizons with days"""
    ONE_WEEK = ("1w", 7)
    ONE_MONTH = ("1m", 30)
    THREE_MONTHS = ("3m", 90)
    TWELVE_MONTHS = ("12m", 365)

@dataclass
class HorizonPrediction:
    """Single horizon prediction data structure"""
    symbol: str
    unternehmen: str
    target_date: datetime  # Zieldatum = heute + zeitraum
    horizon: PredictionHorizon
    soll_gewinn: float
    confidence: Optional[float] = None

class MultiHorizonProfitTracker:
    """
    Multi-Horizon Profit Tracker für separate Datensätze pro Zeithorizont
    """
    
    def __init__(self, db_config: Dict[str, Any] = None):
        """Initialize the multi-horizon profit tracker"""
        self.db_config = db_config or {
            "host": "localhost",
            "port": 5432,
            "database": "aktienanalyse_events",
            "user": "aktienanalyse",
            "password": "secure_password",
            "ssl": "disable"
        }
        
        # Initialize Unified Profit Engine
        if UPE_AVAILABLE:
            self.profit_engine = UnifiedProfitCalculationEngine(
                mode=EngineMode.STANDALONE,
                config={"enable_yfinance": YFINANCE_AVAILABLE}
            )
        else:
            self.profit_engine = None
            logger.error("Unified Profit Engine not available")
    
    async def get_company_name_for_symbol(self, symbol: str) -> str:
        """Get company name for symbol"""
        # Common stock symbol to company name mapping
        symbol_mapping = {
            'AAPL': 'Apple Inc.',
            'MSFT': 'Microsoft Corp.',
            'GOOGL': 'Alphabet Inc.',
            'TSLA': 'Tesla Inc.',
            'AMZN': 'Amazon.com Inc.',
            'NVDA': 'NVIDIA Corp.',
            'META': 'Meta Platforms Inc.',
            'NFLX': 'Netflix Inc.',
            'AMD': 'Advanced Micro Devices Inc.',
            'CRM': 'Salesforce Inc.',
            'ORCL': 'Oracle Corp.',
            'IBM': 'International Business Machines Corp.',
            'INTC': 'Intel Corp.',
            'CSCO': 'Cisco Systems Inc.',
            'ADBE': 'Adobe Inc.'
        }
        
        if symbol.upper() in symbol_mapping:
            return symbol_mapping[symbol.upper()]
        
        # Try to get from yfinance if available
        if YFINANCE_AVAILABLE:
            try:
                ticker = yf.Ticker(symbol)
                info = ticker.info
                return info.get('longName', f'{symbol} Inc.')
            except Exception as e:
                logger.warning(f"Could not fetch company name for {symbol}: {e}")
        
        return f"{symbol} Inc."
    
    async def get_market_data_for_prediction(self, symbol: str) -> Dict[str, Any]:
        """Get current market data for profit prediction"""
        market_data = {
            'symbol': symbol,
            'timestamp': datetime.utcnow().isoformat(),
            'daily_change_percent': 0.0,
            'volume': 0,
            'price': 100.0,  # Default fallback
        }
        
        if YFINANCE_AVAILABLE:
            try:
                ticker = yf.Ticker(symbol)
                hist = ticker.history(period="5d")
                
                if not hist.empty:
                    current_price = hist['Close'].iloc[-1]
                    prev_price = hist['Close'].iloc[-2] if len(hist) > 1 else current_price
                    
                    daily_change = ((current_price - prev_price) / prev_price) * 100
                    volume = hist['Volume'].iloc[-1] if 'Volume' in hist else 0
                    
                    market_data.update({
                        'daily_change_percent': float(daily_change),
                        'volume': int(volume),
                        'price': float(current_price)
                    })
                    
            except Exception as e:
                logger.warning(f"Could not fetch market data for {symbol}: {e}")
        
        return market_data
    
    async def generate_horizon_predictions(self, symbol: str) -> List[HorizonPrediction]:
        """Generate predictions for all time horizons as separate entries"""
        company_name = await self.get_company_name_for_symbol(symbol)
        market_data = await self.get_market_data_for_prediction(symbol)
        
        predictions = []
        base_date = datetime.now().date()
        
        # Generate prediction for each horizon
        for horizon in PredictionHorizon:
            horizon_name, days = horizon.value
            target_date = base_date + timedelta(days=days)
            
            if self.profit_engine:
                try:
                    # Create prediction using unified engine
                    profit_pred = await self.profit_engine.create_profit_prediction(
                        symbol=symbol,
                        company_name=company_name,
                        market_data=market_data
                    )
                    
                    # Scale prediction based on time horizon
                    base_profit = profit_pred.profit_forecast
                    time_scaling_factor = (days / 7.0) ** 0.5  # Square root scaling
                    
                    # Add horizon-specific adjustments
                    horizon_adjustments = {
                        PredictionHorizon.ONE_WEEK: 1.0,
                        PredictionHorizon.ONE_MONTH: 0.9,   # Slightly more conservative
                        PredictionHorizon.THREE_MONTHS: 0.8,  # More conservative
                        PredictionHorizon.TWELVE_MONTHS: 0.7   # Most conservative
                    }
                    
                    adjusted_profit = base_profit * time_scaling_factor * horizon_adjustments[horizon]
                    
                    prediction = HorizonPrediction(
                        symbol=symbol.upper(),
                        unternehmen=company_name,
                        target_date=target_date,
                        horizon=horizon,
                        soll_gewinn=round(adjusted_profit, 4),
                        confidence=profit_pred.confidence_level
                    )
                    
                    predictions.append(prediction)
                    
                except Exception as e:
                    logger.error(f"Error generating prediction for {symbol} {horizon_name}: {e}")
                    # Fallback prediction
                    fallback_values = {
                        PredictionHorizon.ONE_WEEK: 1.0,
                        PredictionHorizon.ONE_MONTH: 1.2,
                        PredictionHorizon.THREE_MONTHS: 1.5,
                        PredictionHorizon.TWELVE_MONTHS: 2.0
                    }
                    
                    prediction = HorizonPrediction(
                        symbol=symbol.upper(),
                        unternehmen=company_name,
                        target_date=target_date,
                        horizon=horizon,
                        soll_gewinn=fallback_values[horizon],
                        confidence=0.5
                    )
                    
                    predictions.append(prediction)
            else:
                # Fallback predictions if engine not available
                fallback_values = {
                    PredictionHorizon.ONE_WEEK: 1.0,
                    PredictionHorizon.ONE_MONTH: 1.2,
                    PredictionHorizon.THREE_MONTHS: 1.5,
                    PredictionHorizon.TWELVE_MONTHS: 2.0
                }
                
                prediction = HorizonPrediction(
                    symbol=symbol.upper(),
                    unternehmen=company_name,
                    target_date=target_date,
                    horizon=horizon,
                    soll_gewinn=fallback_values[horizon],
                    confidence=0.5
                )
                
                predictions.append(prediction)
        
        return predictions
    
    async def store_horizon_prediction(self, prediction: HorizonPrediction) -> bool:
        """Store single horizon prediction in PostgreSQL tracking table"""
        if not ASYNCPG_AVAILABLE:
            logger.error("PostgreSQL not available")
            return False
        
        try:
            conn = await asyncpg.connect(**self.db_config)
            
            # Determine which column to update based on horizon
            column_mapping = {
                PredictionHorizon.ONE_WEEK: "soll_gewinn_1w",
                PredictionHorizon.ONE_MONTH: "soll_gewinn_1m", 
                PredictionHorizon.THREE_MONTHS: "soll_gewinn_3m",
                PredictionHorizon.TWELVE_MONTHS: "soll_gewinn_12m"
            }
            
            column_name = column_mapping[prediction.horizon]
            
            # Insert or update with UPSERT pattern
            query = f"""
            INSERT INTO soll_ist_gewinn_tracking 
                (datum, symbol, unternehmen, {column_name})
            VALUES ($1, $2, $3, $4)
            ON CONFLICT (datum, symbol) 
            DO UPDATE SET 
                {column_name} = EXCLUDED.{column_name},
                updated_at = CURRENT_TIMESTAMP
            """
            
            await conn.execute(
                query,
                prediction.target_date,
                prediction.symbol,
                prediction.unternehmen,
                prediction.soll_gewinn
            )
            
            await conn.close()
            
            horizon_name = prediction.horizon.value[0]
            logger.info(f"✅ Stored {horizon_name} prediction for {prediction.symbol} on {prediction.target_date}: {prediction.soll_gewinn}€")
            return True
            
        except Exception as e:
            logger.error(f"Error storing horizon prediction: {e}")
            return False
    
    async def generate_and_store_multi_horizon_predictions(self, symbols: List[str]) -> Dict[str, Any]:
        """Complete workflow: Generate and store predictions for all horizons"""
        results = {
            "success_count": 0,
            "error_count": 0,
            "predictions_by_horizon": {
                "1w": [],
                "1m": [],
                "3m": [],
                "12m": []
            },
            "errors": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        for symbol in symbols:
            try:
                # Generate predictions for all horizons
                horizon_predictions = await self.generate_horizon_predictions(symbol)
                
                # Store each horizon prediction
                for prediction in horizon_predictions:
                    try:
                        success = await self.store_horizon_prediction(prediction)
                        if success:
                            results["success_count"] += 1
                            horizon_key = prediction.horizon.value[0]
                            results["predictions_by_horizon"][horizon_key].append({
                                "symbol": prediction.symbol,
                                "target_date": prediction.target_date.isoformat(),
                                "soll_gewinn": prediction.soll_gewinn,
                                "confidence": prediction.confidence
                            })
                        else:
                            results["error_count"] += 1
                            results["errors"].append(f"Failed to store {prediction.horizon.value[0]} prediction for {symbol}")
                    except Exception as e:
                        results["error_count"] += 1
                        results["errors"].append(f"Error processing {prediction.horizon.value[0]} for {symbol}: {str(e)}")
                        
            except Exception as e:
                results["error_count"] += 4  # All 4 horizons failed
                results["errors"].append(f"Error generating predictions for {symbol}: {str(e)}")
        
        logger.info(f"🎯 Multi-horizon prediction update completed: {results['success_count']} success, {results['error_count']} errors")
        return results


async def main():
    """Main function for testing and standalone execution"""
    print("🚀 Multi-Horizon Profit Tracker v3.2.0")
    print("=" * 60)
    
    # Test symbols
    test_symbols = ['AAPL', 'MSFT', 'GOOGL']
    
    # Initialize tracker
    tracker = MultiHorizonProfitTracker()
    
    # Run multi-horizon integration
    results = await tracker.generate_and_store_multi_horizon_predictions(test_symbols)
    
    print(f"✅ Processing completed:")
    print(f"   - Successful predictions: {results['success_count']}")
    print(f"   - Errors: {results['error_count']}")
    
    if results['errors']:
        print(f"❌ Errors:")
        for error in results['errors'][:5]:  # Show first 5 errors
            print(f"   - {error}")
    
    print(f"📊 Predictions by horizon:")
    for horizon, preds in results['predictions_by_horizon'].items():
        if preds:
            print(f"   - {horizon.upper()}: {len(preds)} predictions")
            for pred in preds[:2]:  # Show first 2 of each horizon
                print(f"     • {pred['symbol']} -> {pred['target_date']}: {pred['soll_gewinn']}€")


if __name__ == "__main__":
    asyncio.run(main())