#!/usr/bin/env python3
"""
Test Multi-Horizon API v1.0.0
Test Script für die erweiterte Multi-Horizon Profit Tracking API

Author: Claude Code
Version: 1.0.0
Date: 2024-08-24
"""

import asyncio
import json
from datetime import datetime
import sys
import os

# Add path for module imports
sys.path.append('/home/mdoehler/aktienanalyse-ökosystem/services/calculation-engine')

# Direct import of the multi-horizon tracker
try:
    from multi_horizon_profit_tracker_v3_2_0_20250824 import MultiHorizonProfitTracker
    TRACKER_AVAILABLE = True
except ImportError:
    TRACKER_AVAILABLE = False
    print("❌ Multi-Horizon Tracker not available")

async def test_direct_multi_horizon():
    """Test the multi-horizon tracker directly"""
    print("🧪 Testing Multi-Horizon Profit Tracker v3.2.0")
    print("=" * 60)
    
    if not TRACKER_AVAILABLE:
        print("❌ Cannot test - Multi-Horizon Tracker not available")
        return
    
    # Test symbols
    test_symbols = ['TSLA', 'AMD']
    
    # Initialize tracker
    tracker = MultiHorizonProfitTracker()
    
    # Run multi-horizon integration
    print(f"📊 Testing with symbols: {', '.join(test_symbols)}")
    results = await tracker.generate_and_store_multi_horizon_predictions(test_symbols)
    
    print(f"\n✅ Test Results:")
    print(f"   - Total predictions stored: {results['success_count']}")
    print(f"   - Errors: {results['error_count']}")
    
    if results['errors']:
        print(f"\n❌ Errors encountered:")
        for error in results['errors']:
            print(f"   - {error}")
    
    print(f"\n📊 Predictions by horizon:")
    for horizon, predictions in results['predictions_by_horizon'].items():
        if predictions:
            print(f"   - {horizon.upper()}: {len(predictions)} predictions")
            for pred in predictions:
                print(f"     • {pred['symbol']} -> {pred['target_date']}: {pred['soll_gewinn']}€ (confidence: {pred['confidence']})")

async def verify_database_entries():
    """Verify that entries were created in the database"""
    print(f"\n🔍 Database Verification:")
    print("   You can verify the stored predictions with this SQL query:")
    print("""
   sudo -u postgres psql -d aktienanalyse_events -c "
   SELECT 
       datum,
       symbol,
       COALESCE(soll_gewinn_1w::text, 'NULL') as gewinn_1w,
       COALESCE(soll_gewinn_1m::text, 'NULL') as gewinn_1m,
       COALESCE(soll_gewinn_3m::text, 'NULL') as gewinn_3m,
       COALESCE(soll_gewinn_12m::text, 'NULL') as gewinn_12m
   FROM soll_ist_gewinn_tracking 
   WHERE symbol IN ('TSLA', 'AMD')
   AND datum >= CURRENT_DATE
   ORDER BY symbol, datum;
   "
   """)

def explain_multi_horizon_concept():
    """Explain how the multi-horizon system works"""
    print(f"\n💡 Multi-Horizon Konzept Erklärung:")
    print("=" * 50)
    print("Das System erstellt für jedes Symbol 4 separate Datenbankeinträge:")
    print("")
    print("📅 Datumsberechnung:")
    print("   • 1W Vorhersage  -> Zieldatum: heute + 7 Tage")
    print("   • 1M Vorhersage  -> Zieldatum: heute + 30 Tage") 
    print("   • 3M Vorhersage  -> Zieldatum: heute + 90 Tage")
    print("   • 12M Vorhersage -> Zieldatum: heute + 365 Tage")
    print("")
    print("🗃️ Datenbankstruktur:")
    print("   Jeder Datensatz hat nur EINE Vorhersage-Spalte gefüllt:")
    print("   • Datum: 2024-08-31, AAPL, soll_gewinn_1w: 2.10€")
    print("   • Datum: 2024-09-23, AAPL, soll_gewinn_1m: 2.30€") 
    print("   • Datum: 2024-11-22, AAPL, soll_gewinn_3m: 2.60€")
    print("   • Datum: 2025-08-24, AAPL, soll_gewinn_12m: 3.20€")
    print("")
    print("🎯 Vorteil:")
    print("   - Klare Zuordnung: Jede Vorhersage hat ihr spezifisches Zieldatum")
    print("   - IST-Gewinn kann später am korrekten Datum verglichen werden") 
    print("   - Separate Auswertung pro Zeithorizont möglich")

async def main():
    """Main test function"""
    print("🚀 Multi-Horizon Profit Tracking Test Suite")
    print(f"⏰ Testzeit: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    
    # Test 1: Direct multi-horizon tracker
    await test_direct_multi_horizon()
    
    # Test 2: Explain concept
    explain_multi_horizon_concept()
    
    # Test 3: Database verification guide
    await verify_database_entries()
    
    print(f"\n🎉 Test Suite completed!")
    print("=" * 70)

if __name__ == "__main__":
    asyncio.run(main())