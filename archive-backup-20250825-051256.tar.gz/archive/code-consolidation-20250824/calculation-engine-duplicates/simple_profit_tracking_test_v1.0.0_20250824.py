#!/usr/bin/env python3
"""
Simple Profit Tracking Test v1.0.0
Vereinfachter Test für die Multi-Horizon Gewinn-Tracking Integration ohne externe Abhängigkeiten

Author: Claude Code
Version: 1.0.0
Date: 2024-08-24
"""

import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import logging

try:
    import asyncpg
    ASYNCPG_AVAILABLE = True
except ImportError:
    ASYNCPG_AVAILABLE = False
    logging.error("asyncpg not available")

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SimpleProfitTracker:
    """Vereinfachte Profit Tracking Klasse"""
    
    def __init__(self):
        self.db_config = {
            "host": "localhost",
            "port": 5432,
            "database": "aktienanalyse_events",
            "user": "aktienanalyse",
            "password": "secure_password",
            "ssl": "disable"
        }
    
    def generate_simple_predictions(self, symbol: str) -> Dict[str, Any]:
        """Generiere einfache Vorhersagen für alle Horizonte"""
        base_predictions = {
            'AAPL': {'1w': 2.10, '1m': 2.30, '3m': 2.60, '12m': 3.20},
            'MSFT': {'1w': 3.00, '1m': 3.20, '3m': 3.50, '12m': 4.00},
            'GOOGL': {'1w': 1.80, '1m': 2.00, '3m': 2.30, '12m': 2.80},
            'TSLA': {'1w': 1.10, '1m': 1.25, '3m': 1.45, '12m': 1.80},
            'AMZN': {'1w': 2.50, '1m': 2.70, '3m': 3.00, '12m': 3.50}
        }
        
        company_names = {
            'AAPL': 'Apple Inc.',
            'MSFT': 'Microsoft Corp.',
            'GOOGL': 'Alphabet Inc.',
            'TSLA': 'Tesla Inc.',
            'AMZN': 'Amazon.com Inc.'
        }
        
        predictions = base_predictions.get(symbol, {'1w': 1.0, '1m': 1.2, '3m': 1.5, '12m': 2.0})
        
        return {
            'symbol': symbol,
            'unternehmen': company_names.get(symbol, f'{symbol} Inc.'),
            'datum': datetime.now().date(),
            'soll_gewinn_1w': predictions['1w'],
            'soll_gewinn_1m': predictions['1m'],
            'soll_gewinn_3m': predictions['3m'],
            'soll_gewinn_12m': predictions['12m']
        }
    
    async def store_prediction(self, prediction: Dict[str, Any]) -> bool:
        """Speichere Vorhersage in der Datenbank"""
        if not ASYNCPG_AVAILABLE:
            logger.error("PostgreSQL not available")
            return False
        
        try:
            conn = await asyncpg.connect(**self.db_config)
            
            # Insert using standard INSERT (no ON CONFLICT)
            query = """
            INSERT INTO soll_ist_gewinn_tracking 
                (datum, symbol, unternehmen, soll_gewinn_1w, soll_gewinn_1m, soll_gewinn_3m, soll_gewinn_12m)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            """
            
            await conn.execute(
                query,
                prediction['datum'],
                prediction['symbol'],
                prediction['unternehmen'],
                prediction['soll_gewinn_1w'],
                prediction['soll_gewinn_1m'],
                prediction['soll_gewinn_3m'],
                prediction['soll_gewinn_12m']
            )
            
            await conn.close()
            logger.info(f"Successfully stored prediction for {prediction['symbol']} on {prediction['datum']}")
            return True
            
        except Exception as e:
            logger.error(f"Error storing prediction: {e}")
            return False
    
    async def test_integration(self, symbols: List[str]) -> Dict[str, Any]:
        """Teste die Integration mit gegebenen Symbolen"""
        results = {
            "success_count": 0,
            "error_count": 0,
            "predictions": [],
            "errors": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        for symbol in symbols:
            try:
                # Generiere Vorhersage
                prediction = self.generate_simple_predictions(symbol.upper())
                
                # Speichere in Datenbank
                success = await self.store_prediction(prediction)
                
                if success:
                    results["success_count"] += 1
                    results["predictions"].append(prediction)
                else:
                    results["error_count"] += 1
                    results["errors"].append(f"Failed to store prediction for {symbol}")
                    
            except Exception as e:
                results["error_count"] += 1
                results["errors"].append(f"Error processing {symbol}: {str(e)}")
        
        return results

async def main():
    """Haupt-Test-Funktion"""
    print("🧪 Simple Profit Tracking Test v1.0.0")
    print("=" * 50)
    
    # Test Symbole
    test_symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA', 'AMZN']
    
    # Erstelle Tracker
    tracker = SimpleProfitTracker()
    
    # Führe Test durch
    results = await tracker.test_integration(test_symbols)
    
    print(f"✅ Test abgeschlossen:")
    print(f"   - Erfolgreich: {results['success_count']}")
    print(f"   - Fehler: {results['error_count']}")
    
    if results['errors']:
        print(f"❌ Fehler:")
        for error in results['errors']:
            print(f"   - {error}")
    
    if results['predictions']:
        print(f"📊 Gespeicherte Vorhersagen:")
        for pred in results['predictions']:
            print(f"   - {pred['symbol']}: 1W={pred['soll_gewinn_1w']}€, 1M={pred['soll_gewinn_1m']}€, 3M={pred['soll_gewinn_3m']}€, 12M={pred['soll_gewinn_12m']}€")

if __name__ == "__main__":
    asyncio.run(main())