#!/usr/bin/env python3
"""
Global Market Database Integration v1.0.0
Integration aller globalen Marktdaten in die Gewinn-Tracking Tabelle

FEATURES:
- Integration aller 132 globalen Vorhersagen in PostgreSQL
- Multi-Currency Support mit EUR-Konvertierung  
- Globale Marktabdeckung: 11 Marktkategorien
- High-Quality Database Operations
- Comprehensive Error Handling

Author: Claude Code & Aktienanalyse Team
Version: 1.0.0
Date: 2024-08-24
"""

import asyncio
import sys
from datetime import datetime, timedelta, date
from typing import Dict, List, Any
import logging

# Use virtual environment
sys.path.insert(0, '/home/mdoehler/aktienanalyse-venv/lib/python3.11/site-packages')

try:
    import asyncpg
    ASYNCPG_AVAILABLE = True
except ImportError:
    ASYNCPG_AVAILABLE = False
    logging.error("asyncpg not available")

# Import the global collector
sys.path.append('/home/mdoehler/aktienanalyse-ökosystem/services/calculation-engine')

# Import components from global collector file
exec(open('/home/mdoehler/aktienanalyse-ökosystem/services/calculation-engine/global_market_data_collector_v1.0.0_20250824.py').read())

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class GlobalMarketDatabaseIntegrator:
    """
    High-Quality Database Integration für globale Märkte
    """
    
    def __init__(self):
        self.db_config = {
            "host": "localhost",
            "port": 5432,
            "database": "aktienanalyse_events",
            "user": "aktienanalyse", 
            "password": "secure_password",
            "ssl": "disable"
        }
        
        self.horizon_mapping = {
            "1w": "soll_gewinn_1w",
            "1m": "soll_gewinn_1m", 
            "3m": "soll_gewinn_3m",
            "12m": "soll_gewinn_12m"
        }
    
    async def store_global_prediction(self, prediction: Dict[str, Any]) -> bool:
        """Store global market prediction in database"""
        if not ASYNCPG_AVAILABLE:
            return False
        
        try:
            conn = await asyncpg.connect(**self.db_config)
            
            column_name = self.horizon_mapping[prediction['horizon']]
            target_date = datetime.fromisoformat(prediction['target_date']).date()
            
            # UPSERT with global market data
            query = f"""
            INSERT INTO soll_ist_gewinn_tracking 
                (datum, symbol, unternehmen, {column_name})
            VALUES ($1, $2, $3, $4)
            ON CONFLICT (datum, symbol) 
            DO UPDATE SET 
                {column_name} = EXCLUDED.{column_name},
                updated_at = CURRENT_TIMESTAMP
            """
            
            await conn.execute(
                query,
                target_date,
                prediction['symbol'],
                prediction['company_name'],
                prediction['profit_forecast']
            )
            
            await conn.close()
            
            logger.info(f"✅ Stored global {prediction['horizon']} prediction: {prediction['symbol']} ({prediction['market_region']}) -> {prediction['profit_forecast']}€")
            return True
            
        except Exception as e:
            logger.error(f"Database error storing {prediction['symbol']}: {e}")
            return False
    
    async def integrate_all_global_markets(self) -> Dict[str, Any]:
        """Integrate all global markets into database"""
        logger.info("🌍 Starting global market integration...")
        
        # Collect global market data
        collector = GlobalMarketDataCollector()
        results = await collector.process_all_global_markets(max_symbols_per_market=5)  # More symbols
        
        # Store in database
        storage_results = {
            "stored_count": 0,
            "storage_errors": 0,
            "market_breakdown": {},
            "errors": []
        }
        
        for prediction in results['predictions']:
            stored = await self.store_global_prediction(prediction)
            if stored:
                storage_results["stored_count"] += 1
                
                # Track by market
                market = prediction['market_region']
                if market not in storage_results["market_breakdown"]:
                    storage_results["market_breakdown"][market] = 0
                storage_results["market_breakdown"][market] += 1
            else:
                storage_results["storage_errors"] += 1
                storage_results["errors"].append(f"Failed to store {prediction['symbol']}")
        
        logger.info(f"🎯 Global integration completed: {storage_results['stored_count']} stored, {storage_results['storage_errors']} errors")
        
        return {
            "collection_results": results,
            "storage_results": storage_results
        }

async def main():
    """Main function for global market integration"""
    print("🌍 Global Market Database Integration v1.0.0")
    print("📊 Integration aller verfügbaren Märkte in die Datenbank")
    print("=" * 80)
    
    integrator = GlobalMarketDatabaseIntegrator()
    
    # Integrate all global markets
    results = await integrator.integrate_all_global_markets()
    
    collection = results["collection_results"]
    storage = results["storage_results"]
    
    print(f"\n✅ Global Integration Results:")
    print(f"   - Market data collected: {collection['success_count']} predictions")
    print(f"   - Database storage: {storage['stored_count']} predictions")
    print(f"   - Collection time: {collection['processing_time']}s")
    
    print(f"\n🌍 Market Coverage in Database:")
    for market, count in storage['market_breakdown'].items():
        print(f"   - {market}: {count} predictions stored")
    
    print(f"\n📈 Global Market Categories:")
    for category, symbols in collection['market_coverage'].items():
        print(f"   - {category}: {symbols} symbols processed")
    
    if storage['errors'][:3]:
        print(f"\n❌ Storage Errors (Sample):")
        for error in storage['errors'][:3]:
            print(f"   - {error}")

if __name__ == "__main__":
    asyncio.run(main())