#!/usr/bin/env python3
"""
Unified Profit Engine FastAPI Service v3.1.0
FastAPI Service-Wrapper für die Unified Profit Calculation Engine mit Multi-Horizon Integration

NEUE FEATURES v3.1.0:
- Multi-Horizon SOLL-IST Tracking Integration
- Automated Prediction Storage
- Enhanced API Endpoints
- Real-time Prediction Generation

FEATURES:
- Backward compatible APIs mit bestehenden Services
- Multi-Mode Support (Full/Standalone/Simple)
- ML-Pipeline Integration Ready
- Multi-Horizon Profit Tracking
- Comprehensive Error Handling
- Performance Monitoring
- SOLL-IST Vergleichsdaten für Frontend

PORTS:
- Default: 8025 (aus original profit_calculation_engine v2.0.0)

API ENDPOINTS:
- POST /api/v1/profit/calculate - Create profit prediction
- POST /api/v1/profit/multihorizon/generate - Generate multi-horizon predictions
- POST /api/v1/profit/multihorizon/store - Store predictions in tracking table
- GET /api/v1/profit/soll-ist-comparison - SOLL-IST comparison data
- GET /api/v1/profit/analytics - Performance analytics
- GET /api/v1/profit/health - Health check
- GET /api/v1/profit/metrics - Engine metrics

Code-Qualität: HÖCHSTE PRIORITÄT
"""

import asyncio
import sys
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Union
import json
import logging
from contextlib import asynccontextmanager

# FastAPI Dependencies
try:
    from fastapi import FastAPI, HTTPException, Depends, Query, Body
    from fastapi.responses import JSONResponse
    from fastapi.middleware.cors import CORSMiddleware
    from pydantic import BaseModel, Field, ValidationError
    import uvicorn
    FASTAPI_AVAILABLE = True
except ImportError:
    FASTAPI_AVAILABLE = False
    logging.error("FastAPI dependencies not available")

# Import Management - Clean Architecture
from shared.standard_import_manager_v1_0_0_20250824 import setup_aktienanalyse_imports
setup_aktienanalyse_imports()  # Replaces all sys.path.append statements

try:
    from unified_profit_calculation_engine_v3_0_0_20250823 import (
        UnifiedProfitCalculationEngine, EngineMode, UnifiedProfitPrediction, PredictionSource
    )
    UNIFIED_ENGINE_AVAILABLE = True
except ImportError:
    UNIFIED_ENGINE_AVAILABLE = False
    logging.error("Unified Profit Engine not available")

try:
    from profit_tracking_integration_v3_1_0_20250824 import (
        ProfitTrackingIntegrator, MultiHorizonPrediction, PredictionHorizon
    )
    TRACKING_INTEGRATION_AVAILABLE = True
except ImportError:
    TRACKING_INTEGRATION_AVAILABLE = False
    logging.error("Profit Tracking Integration not available")

try:
    from multi_horizon_profit_tracker_v3_2_0_20250824 import (
        MultiHorizonProfitTracker, HorizonPrediction
    )
    MULTI_HORIZON_AVAILABLE = True
except ImportError:
    MULTI_HORIZON_AVAILABLE = False
    logging.error("Multi Horizon Profit Tracker not available")

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Pydantic Models
class ProfitCalculationRequest(BaseModel):
    """Request model for profit calculation"""
    symbol: str = Field(..., description="Stock symbol")
    company_name: Optional[str] = Field(None, description="Company name")
    market_data: Dict[str, Any] = Field(..., description="Market data")
    source: str = Field("internal_model", description="Prediction source")

class MultiHorizonGenerateRequest(BaseModel):
    """Request model for multi-horizon prediction generation"""
    symbols: List[str] = Field(..., description="List of stock symbols")

class MultiHorizonStoreRequest(BaseModel):
    """Request model for storing multi-horizon predictions"""
    symbols: List[str] = Field(..., description="List of stock symbols")
    store_in_db: bool = Field(True, description="Whether to store in database")

class SollIstComparisonRequest(BaseModel):
    """Request model for SOLL-IST comparison"""
    symbol: Optional[str] = Field(None, description="Filter by symbol")
    timeframe_days: int = Field(30, ge=1, le=365, description="Timeframe in days")
    limit: int = Field(100, ge=1, le=1000, description="Maximum number of results")

class SollIstComparisonResponse(BaseModel):
    """Response model for SOLL-IST comparison"""
    success: bool
    data: List[Dict[str, Any]]
    count: int
    timeframe_days: int
    generated_at: str
    error: Optional[str] = None

class MultiHorizonResponse(BaseModel):
    """Response model for multi-horizon operations"""
    success: bool
    success_count: int
    error_count: int
    predictions: List[Dict[str, Any]]
    errors: List[str]
    timestamp: str

class PerformanceAnalyticsResponse(BaseModel):
    """Response model for performance analytics"""
    success: bool
    analytics: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

class HealthCheckResponse(BaseModel):
    """Response model for health check"""
    status: str
    mode: str
    uptime: str
    version: str
    components: Dict[str, str]
    metrics: Dict[str, Any]

# Global instances
engine: Optional[UnifiedProfitCalculationEngine] = None
tracking_integrator: Optional[ProfitTrackingIntegrator] = None
multi_horizon_tracker: Optional[MultiHorizonProfitTracker] = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """FastAPI lifespan context manager"""
    global engine, tracking_integrator, multi_horizon_tracker
    
    try:
        # Startup
        logger.info("Starting Unified Profit Engine Service v3.1.0")
        
        if not UNIFIED_ENGINE_AVAILABLE:
            raise Exception("Unified Engine not available")
        
        # Determine mode from environment
        mode_str = os.getenv('PROFIT_ENGINE_MODE', 'standalone').lower()
        try:
            mode = EngineMode(mode_str)
        except ValueError:
            logger.warning(f"Invalid mode '{mode_str}', using STANDALONE")
            mode = EngineMode.STANDALONE
        
        # Initialize engine
        engine_config = {
            'enable_yfinance': True,
            'max_concurrent_predictions': 10
        }
        
        engine = UnifiedProfitCalculationEngine(mode=mode, config=engine_config)
        
        # Initialize tracking integrator
        if TRACKING_INTEGRATION_AVAILABLE:
            tracking_integrator = ProfitTrackingIntegrator()
            logger.info("Tracking integrator initialized")
        else:
            logger.warning("Tracking integrator not available")
        
        # Initialize multi-horizon tracker
        if MULTI_HORIZON_AVAILABLE:
            multi_horizon_tracker = MultiHorizonProfitTracker()
            logger.info("Multi-horizon tracker initialized")
        else:
            logger.warning("Multi-horizon tracker not available")
        
        logger.info(f"Engine initialized successfully in {mode.value} mode")
        
        yield
        
    except Exception as e:
        logger.error(f"Startup failed: {str(e)}")
        raise
    finally:
        # Cleanup
        logger.info("Shutting down Unified Profit Engine Service")

# Create FastAPI app
if FASTAPI_AVAILABLE:
    app = FastAPI(
        title="Unified Profit Engine Service",
        description="Multi-Horizon Profit Prediction and Tracking API",
        version="3.1.0",
        lifespan=lifespan
    )
    
    # Add CORS middleware für private Entwicklungsumgebung
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Für privaten Gebrauch akzeptabel
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.post("/api/v1/profit/calculate", response_model=Dict[str, Any])
    async def create_profit_prediction(request: ProfitCalculationRequest) -> Dict[str, Any]:
        """Create a profit prediction using the unified engine"""
        if not engine:
            raise HTTPException(status_code=503, detail="Engine not available")
        
        try:
            # Convert source string to enum
            source_map = {
                'internal_model': PredictionSource.INTERNAL_MODEL,
                'external_api': PredictionSource.EXTERNAL_API,
                'hybrid': PredictionSource.HYBRID,
                'manual': PredictionSource.MANUAL
            }
            source = source_map.get(request.source.lower(), PredictionSource.INTERNAL_MODEL)
            
            prediction = await engine.create_profit_prediction(
                symbol=request.symbol,
                company_name=request.company_name or f"{request.symbol} Inc.",
                market_data=request.market_data,
                source=source
            )
            
            return {
                "success": True,
                "prediction": {
                    "prediction_id": prediction.prediction_id,
                    "symbol": prediction.symbol,
                    "company_name": prediction.company_name,
                    "profit_forecast": prediction.profit_forecast,
                    "confidence_level": prediction.confidence_level,
                    "forecast_period_days": prediction.forecast_period_days,
                    "target_date": prediction.target_date.isoformat(),
                    "source": prediction.source.value,
                    "created_at": prediction.created_at.isoformat()
                }
            }
            
        except Exception as e:
            logger.error(f"Error creating profit prediction: {str(e)}")
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/v1/profit/multihorizon/generate", response_model=MultiHorizonResponse)
    async def generate_multihorizon_predictions(request: MultiHorizonGenerateRequest) -> MultiHorizonResponse:
        """Generate multi-horizon predictions for given symbols"""
        if not tracking_integrator:
            raise HTTPException(status_code=503, detail="Tracking integrator not available")
        
        try:
            predictions = await tracking_integrator.generate_predictions_for_symbols(request.symbols)
            
            formatted_predictions = []
            for pred in predictions:
                formatted_predictions.append({
                    "symbol": pred.symbol,
                    "unternehmen": pred.unternehmen,
                    "datum": pred.datum.isoformat(),
                    "soll_gewinn_1w": pred.soll_gewinn_1w,
                    "soll_gewinn_1m": pred.soll_gewinn_1m,
                    "soll_gewinn_3m": pred.soll_gewinn_3m,
                    "soll_gewinn_12m": pred.soll_gewinn_12m,
                    "confidence_1w": pred.confidence_1w,
                    "confidence_1m": pred.confidence_1m,
                    "confidence_3m": pred.confidence_3m,
                    "confidence_12m": pred.confidence_12m
                })
            
            return MultiHorizonResponse(
                success=True,
                success_count=len(predictions),
                error_count=0,
                predictions=formatted_predictions,
                errors=[],
                timestamp=datetime.utcnow().isoformat()
            )
            
        except Exception as e:
            logger.error(f"Error generating multi-horizon predictions: {str(e)}")
            return MultiHorizonResponse(
                success=False,
                success_count=0,
                error_count=len(request.symbols),
                predictions=[],
                errors=[str(e)],
                timestamp=datetime.utcnow().isoformat()
            )

    @app.post("/api/v1/profit/multihorizon/store", response_model=MultiHorizonResponse)
    async def store_multihorizon_predictions(request: MultiHorizonStoreRequest) -> MultiHorizonResponse:
        """Generate and store multi-horizon predictions in tracking table"""
        if not tracking_integrator:
            raise HTTPException(status_code=503, detail="Tracking integrator not available")
        
        try:
            results = await tracking_integrator.update_tracking_table_with_predictions(request.symbols)
            
            return MultiHorizonResponse(
                success=results["error_count"] == 0,
                success_count=results["success_count"],
                error_count=results["error_count"],
                predictions=results["predictions"],
                errors=results["errors"],
                timestamp=results["timestamp"]
            )
            
        except Exception as e:
            logger.error(f"Error storing multi-horizon predictions: {str(e)}")
            return MultiHorizonResponse(
                success=False,
                success_count=0,
                error_count=len(request.symbols),
                predictions=[],
                errors=[str(e)],
                timestamp=datetime.utcnow().isoformat()
            )

    @app.post("/api/v1/profit/multihorizon/store-separated", response_model=MultiHorizonResponse)
    async def store_multihorizon_predictions_separated(request: MultiHorizonStoreRequest) -> MultiHorizonResponse:
        """Generate and store multi-horizon predictions as separate entries with calculated target dates"""
        if not multi_horizon_tracker:
            raise HTTPException(status_code=503, detail="Multi-horizon tracker not available")
        
        try:
            results = await multi_horizon_tracker.generate_and_store_multi_horizon_predictions(request.symbols)
            
            # Flatten predictions by horizon for response
            all_predictions = []
            for horizon_key, predictions in results["predictions_by_horizon"].items():
                for pred in predictions:
                    pred["horizon"] = horizon_key
                    all_predictions.append(pred)
            
            return MultiHorizonResponse(
                success=results["error_count"] == 0,
                success_count=results["success_count"],
                error_count=results["error_count"],
                predictions=all_predictions,
                errors=results["errors"],
                timestamp=results["timestamp"]
            )
            
        except Exception as e:
            logger.error(f"Error storing separated multi-horizon predictions: {str(e)}")
            return MultiHorizonResponse(
                success=False,
                success_count=0,
                error_count=len(request.symbols) * 4,  # 4 horizons per symbol
                predictions=[],
                errors=[str(e)],
                timestamp=datetime.utcnow().isoformat()
            )

    @app.get("/api/v1/profit/soll-ist-comparison", response_model=SollIstComparisonResponse)
    async def get_soll_ist_comparison(
        symbol: Optional[str] = Query(None, description="Filter by symbol"),
        timeframe_days: int = Query(30, ge=1, le=365, description="Timeframe in days"),
        limit: int = Query(100, ge=1, le=1000, description="Maximum number of results")
    ) -> SollIstComparisonResponse:
        """Get SOLL-IST comparison data"""
        if not engine:
            raise HTTPException(status_code=503, detail="Engine not available")
        
        try:
            # This would typically fetch from the tracking database
            # For now, return a placeholder response
            return SollIstComparisonResponse(
                success=True,
                data=[],
                count=0,
                timeframe_days=timeframe_days,
                generated_at=datetime.utcnow().isoformat(),
                error=None
            )
            
        except Exception as e:
            logger.error(f"Error getting SOLL-IST comparison: {str(e)}")
            return SollIstComparisonResponse(
                success=False,
                data=[],
                count=0,
                timeframe_days=timeframe_days,
                generated_at=datetime.utcnow().isoformat(),
                error=str(e)
            )

    @app.get("/api/v1/profit/analytics", response_model=PerformanceAnalyticsResponse)
    async def get_performance_analytics() -> PerformanceAnalyticsResponse:
        """Get performance analytics"""
        if not engine:
            raise HTTPException(status_code=503, detail="Engine not available")
        
        try:
            # Placeholder analytics
            analytics = {
                "total_predictions": 0,
                "accuracy_rate": 0.0,
                "avg_confidence": 0.0,
                "last_updated": datetime.utcnow().isoformat()
            }
            
            return PerformanceAnalyticsResponse(
                success=True,
                analytics=analytics
            )
            
        except Exception as e:
            logger.error(f"Error getting analytics: {str(e)}")
            return PerformanceAnalyticsResponse(
                success=False,
                error=str(e)
            )

    @app.get("/api/v1/profit/health", response_model=HealthCheckResponse)
    async def health_check() -> HealthCheckResponse:
        """Health check endpoint"""
        components = {
            "unified_engine": "available" if engine else "unavailable",
            "tracking_integrator": "available" if tracking_integrator else "unavailable",
            "multi_horizon_tracker": "available" if multi_horizon_tracker else "unavailable",
            "fastapi": "available" if FASTAPI_AVAILABLE else "unavailable"
        }
        
        metrics = {
            "uptime": "running",
            "version": "3.1.0",
            "mode": engine.mode.value if engine else "unknown",
            "multi_horizon_enabled": multi_horizon_tracker is not None
        }
        
        status = "healthy" if engine else "degraded"
        
        return HealthCheckResponse(
            status=status,
            mode=engine.mode.value if engine else "unknown",
            uptime="running",
            version="3.1.0",
            components=components,
            metrics=metrics
        )

    @app.get("/api/v1/profit/metrics")
    async def get_metrics() -> Dict[str, Any]:
        """Get engine metrics"""
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "version": "3.1.0",
            "status": "running",
            "components": {
                "engine": engine is not None,
                "tracking": tracking_integrator is not None
            }
        }

else:
    app = None
    logger.error("FastAPI not available - service cannot start")


class UnifiedProfitEngineServiceRunner:
    """Service runner for production deployment"""
    
    def __init__(self):
        self.host = os.getenv('HOST', '0.0.0.0')
        self.port = int(os.getenv('PORT', '8025'))
        
    def run(self):
        """Run the service"""
        if not app:
            logger.error("Cannot start service - FastAPI not available")
            return
            
        logger.info(f"Starting Unified Profit Engine Service v3.1.0 on {self.host}:{self.port}")
        
        uvicorn.run(
            app,
            host=self.host,
            port=self.port,
            log_level="info",
            reload=False
        )


if __name__ == "__main__":
    runner = UnifiedProfitEngineServiceRunner()
    runner.run()