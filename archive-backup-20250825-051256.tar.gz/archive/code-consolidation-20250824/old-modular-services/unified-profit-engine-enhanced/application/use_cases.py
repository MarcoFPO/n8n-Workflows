#!/usr/bin/env python3
"""
Application Layer - Use Cases
Unified Profit Engine Enhanced v6.0 - Clean Architecture

USE CASE PATTERN:
- Single Responsibility pro Use Case
- Dependency Injection für Infrastructure
- Business Logic Orchestration
- Event Publishing Integration

Code-Qualität: HÖCHSTE PRIORITÄT - Clean Architecture Principles
Autor: Claude Code - Architecture Refactoring Specialist
Datum: 24. August 2025
"""

from typing import List, Dict, Any, Optional
from datetime import date, datetime
from decimal import Decimal
import logging

from ..domain.entities import (
    ProfitPrediction,
    SOLLISTTracking,
    MarketSymbol,
    PredictionHorizon,
    ProfitForecast,
    PredictionCreatedEvent,
    DomainEvent
)
from ..domain.repositories import (
    ProfitPredictionRepository,
    SOLLISTTrackingRepository,
    MarketDataRepository,
    MarketData,
    PerformanceMetrics
)
from .interfaces import EventPublisher, MLPredictionService


logger = logging.getLogger(__name__)


class GenerateMultiHorizonPredictionsUseCase:
    """
    Use Case: Multi-Horizon Vorhersage-Generierung
    
    SOLID Principles:
    - Single Responsibility: Nur Multi-Horizon Prediction Generation
    - Dependency Inversion: Abhängig von Interfaces, nicht Implementierungen
    """
    
    def __init__(self,
                 market_data_repo: MarketDataRepository,
                 prediction_repo: ProfitPredictionRepository,
                 soll_ist_repo: SOLLISTTrackingRepository,
                 event_publisher: EventPublisher,
                 ml_service: MLPredictionService):
        self.market_data_repo = market_data_repo
        self.prediction_repo = prediction_repo
        self.soll_ist_repo = soll_ist_repo
        self.event_publisher = event_publisher
        self.ml_service = ml_service
    
    async def execute(self, symbols: List[str]) -> List[SOLLISTTracking]:
        """
        Generiert Multi-Horizon Predictions für alle Symbole
        Integriert mit bestehender Event-Architecture
        """
        logger.info(f"Starting multi-horizon prediction generation for {len(symbols)} symbols")
        results = []
        
        try:
            for symbol in symbols:
                logger.info(f"Processing symbol: {symbol}")
                
                # 1. Market Data beschaffen
                market_data = await self.market_data_repo.get_current_data(symbol)
                market_symbol = MarketSymbol(
                    symbol=symbol,
                    company_name=market_data.company_name,
                    market_region=market_data.market_region
                )
                
                # 2. Predictions für alle Horizonte generieren
                horizons = list(PredictionHorizon)
                forecasts = {}
                
                for horizon in horizons:
                    try:
                        # ML-basierte Vorhersage über Service Interface
                        prediction_result = await self.ml_service.generate_prediction(
                            market_data, horizon
                        )
                        
                        forecast = ProfitForecast(
                            amount=prediction_result['profit_forecast'],
                            confidence=prediction_result['confidence'],
                            horizon=horizon
                        )
                        forecasts[horizon] = forecast
                        
                        logger.info(f"Generated {horizon.value} forecast for {symbol}: {forecast.amount}")
                        
                    except Exception as e:
                        logger.error(f"Failed to generate {horizon.value} forecast for {symbol}: {e}")
                        continue
                
                if not forecasts:
                    logger.warning(f"No forecasts generated for {symbol}")
                    continue
                
                # 3. Prediction Entity erstellen
                prediction = ProfitPrediction(
                    symbol=market_symbol,
                    target_date=date.today(),
                    forecasts=forecasts
                )
                
                # 4. Prediction in Repository speichern
                await self.prediction_repo.save(prediction)
                
                # 5. SOLL-IST Tracking erstellen/aktualisieren
                tracking = await self._create_or_update_tracking(market_symbol, forecasts)
                results.append(tracking)
                
                # 6. Domain Events publizieren
                await self._publish_domain_events(prediction)
                
                # 7. Application Event publizieren
                await self.event_publisher.publish(
                    "analysis.prediction.generated",
                    {
                        "symbol": symbol,
                        "predictions": tracking.to_dict(),
                        "forecast_count": len(forecasts),
                        "timestamp": datetime.now().isoformat(),
                        "service": "unified-profit-engine-enhanced",
                        "version": "6.0"
                    }
                )
                
            logger.info(f"Multi-horizon prediction generation completed for {len(results)} symbols")
            return results
            
        except Exception as e:
            logger.error(f"Multi-horizon prediction generation failed: {e}")
            raise
    
    async def _create_or_update_tracking(self, 
                                       symbol: MarketSymbol, 
                                       forecasts: Dict[PredictionHorizon, ProfitForecast]) -> SOLLISTTracking:
        """Erstellt oder aktualisiert SOLL-IST Tracking"""
        
        # Versuche existierende Tracking zu laden
        tracking = await self.soll_ist_repo.get_by_symbol_and_date(
            symbol.symbol, date.today()
        )
        
        if tracking is None:
            # Neue Tracking erstellen
            tracking = SOLLISTTracking(
                datum=date.today(),
                symbol=symbol
            )
        
        # SOLL-Werte aktualisieren
        for horizon, forecast in forecasts.items():
            tracking.update_soll_gewinn(horizon, forecast.amount)
        
        # Tracking speichern
        await self.soll_ist_repo.save(tracking)
        
        return tracking
    
    async def _publish_domain_events(self, prediction: ProfitPrediction):
        """Publiziert Domain Events"""
        domain_events = prediction.clear_domain_events()
        
        for event in domain_events:
            await self.event_publisher.publish(
                event.event_type(),
                {
                    "event_id": event.event_id,
                    "occurred_at": event.occurred_at.isoformat(),
                    "event_data": event.__dict__ if hasattr(event, '__dict__') else str(event)
                }
            )


class CalculateISTPerformanceUseCase:
    """
    Use Case: IST-Performance Berechnung
    
    SOLID Principles:
    - Single Responsibility: Nur IST-Performance Calculation
    - Open/Closed: Erweiterbar um neue Performance-Metriken
    """
    
    def __init__(self,
                 market_data_repo: MarketDataRepository,
                 soll_ist_repo: SOLLISTTrackingRepository,
                 event_publisher: EventPublisher):
        self.market_data_repo = market_data_repo
        self.soll_ist_repo = soll_ist_repo
        self.event_publisher = event_publisher
    
    async def execute(self, symbols: List[str]) -> Dict[str, Decimal]:
        """Berechnet aktuelle IST-Performance für Symbole"""
        logger.info(f"Starting IST performance calculation for {len(symbols)} symbols")
        results = {}
        
        try:
            for symbol in symbols:
                logger.info(f"Calculating IST performance for: {symbol}")
                
                # Portfolio Performance ermitteln
                ist_gewinn = await self._calculate_ist_profit(symbol)
                
                # SOLL-IST Tracking aktualisieren
                tracking = await self.soll_ist_repo.get_by_symbol_and_date(
                    symbol, date.today()
                )
                
                if tracking:
                    # IST-Wert aktualisieren
                    tracking.update_ist_gewinn(ist_gewinn)
                    await self.soll_ist_repo.update(tracking)
                    
                    # Domain Events publizieren
                    await self._publish_domain_events(tracking)
                    
                    # Application Event publizieren
                    await self.event_publisher.publish(
                        "profit.calculation.completed",
                        {
                            "symbol": symbol,
                            "ist_gewinn": float(ist_gewinn),
                            "soll_ist_tracking": tracking.to_dict(),
                            "performance_analysis": self._calculate_performance_analysis(tracking),
                            "timestamp": datetime.now().isoformat(),
                            "service": "unified-profit-engine-enhanced",
                            "version": "6.0"
                        }
                    )
                    
                    logger.info(f"IST performance calculated for {symbol}: {ist_gewinn}")
                else:
                    logger.warning(f"No SOLL-IST tracking found for {symbol}")
                
                results[symbol] = ist_gewinn
            
            logger.info(f"IST performance calculation completed for {len(results)} symbols")
            return results
            
        except Exception as e:
            logger.error(f"IST performance calculation failed: {e}")
            raise
    
    async def _calculate_ist_profit(self, symbol: str) -> Decimal:
        """Business Logic: IST-Gewinn Berechnung"""
        try:
            # Aktuelle Marktdaten laden
            current_data = await self.market_data_repo.get_current_data(symbol)
            
            # Historische Daten für Vergleich laden (7 Tage)
            historical_data = await self.market_data_repo.get_historical_data(symbol, 7)
            
            if not historical_data:
                raise ValueError(f"No historical data available for {symbol}")
            
            # Simple Performance-Berechnung: Aktuelle vs 7-Tage-Durchschnitt
            historical_avg = sum(data.current_price for data in historical_data) / len(historical_data)
            performance = current_data.current_price - historical_avg
            
            return performance
            
        except Exception as e:
            logger.error(f"IST profit calculation failed for {symbol}: {e}")
            raise
    
    def _calculate_performance_analysis(self, tracking: SOLLISTTracking) -> Dict[str, Any]:
        """Berechnet Performance-Analyse für Tracking"""
        analysis = {}
        
        for horizon in PredictionHorizon:
            diff = tracking.calculate_performance_diff(horizon)
            accuracy = tracking.calculate_accuracy_percentage(horizon)
            
            analysis[f"performance_{horizon.value.lower()}"] = {
                "difference": float(diff) if diff else None,
                "accuracy_percentage": accuracy,
                "soll_value": float(tracking.get_soll_gewinn(horizon)) if tracking.get_soll_gewinn(horizon) else None
            }
        
        analysis["best_performing_horizon"] = tracking.get_best_performing_horizon().value if tracking.get_best_performing_horizon() else None
        analysis["ist_gewinn"] = float(tracking.ist_gewinn) if tracking.ist_gewinn else None
        
        return analysis
    
    async def _publish_domain_events(self, tracking: SOLLISTTracking):
        """Publiziert Domain Events"""
        domain_events = tracking.clear_domain_events()
        
        for event in domain_events:
            await self.event_publisher.publish(
                event.event_type(),
                {
                    "event_id": event.event_id,
                    "occurred_at": event.occurred_at.isoformat(),
                    "event_data": event.__dict__ if hasattr(event, '__dict__') else str(event)
                }
            )


class GetPerformanceAnalysisUseCase:
    """
    Use Case: Performance-Analyse Abruf
    
    SOLID Principles:
    - Single Responsibility: Nur Performance-Analyse Retrieval
    - Interface Segregation: Spezifische Query-Interfaces
    """
    
    def __init__(self, soll_ist_repo: SOLLISTTrackingRepository):
        self.soll_ist_repo = soll_ist_repo
    
    async def execute(self, 
                     symbol: Optional[str] = None,
                     horizon: Optional[PredictionHorizon] = None,
                     start_date: Optional[date] = None,
                     end_date: Optional[date] = None) -> List[PerformanceMetrics]:
        """
        Lädt Performance-Analyse basierend auf Filtern
        """
        logger.info(f"Loading performance analysis - Symbol: {symbol}, Horizon: {horizon}")
        
        try:
            # Performance-Daten laden
            performance_data = await self.soll_ist_repo.get_performance_analysis(
                symbol=symbol,
                horizon=horizon
            )
            
            # Zu PerformanceMetrics konvertieren
            metrics = []
            for data in performance_data:
                metric = PerformanceMetrics(
                    symbol=data['symbol'],
                    tracking_date=data['datum'],
                    ist_gewinn=data.get('ist_gewinn'),
                    soll_1w=data.get('soll_gewinn_1w'),
                    soll_1m=data.get('soll_gewinn_1m'),
                    soll_3m=data.get('soll_gewinn_3m'),
                    soll_12m=data.get('soll_gewinn_12m'),
                    diff_1w=data.get('diff_1w'),
                    diff_1m=data.get('diff_1m'),
                    diff_3m=data.get('diff_3m'),
                    diff_12m=data.get('diff_12m'),
                    accuracy_1w=data.get('accuracy_1w'),
                    accuracy_1m=data.get('accuracy_1m'),
                    accuracy_3m=data.get('accuracy_3m'),
                    accuracy_12m=data.get('accuracy_12m'),
                    best_horizon=data.get('best_horizon'),
                    worst_horizon=data.get('worst_horizon'),
                    overall_accuracy=data.get('overall_accuracy')
                )
                metrics.append(metric)
            
            logger.info(f"Loaded {len(metrics)} performance metrics")
            return metrics
            
        except Exception as e:
            logger.error(f"Performance analysis retrieval failed: {e}")
            raise