#!/usr/bin/env python3
"""
Application Layer - Service Interfaces
Unified Profit Engine Enhanced v6.0 - Clean Architecture

INTERFACE SEGREGATION:
- Spezifische Interfaces für verschiedene Concerns
- Dependency Inversion Principle
- Testbare Abstractions

Code-Qualität: HÖCHSTE PRIORITÄT - Clean Architecture Principles
Autor: Claude Code - Architecture Refactoring Specialist
Datum: 24. August 2025
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from datetime import datetime

from ..domain.entities import PredictionHorizon
from ..domain.repositories import MarketData


class EventPublisher(ABC):
    """Interface für Event Publishing"""
    
    @abstractmethod
    async def publish(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """Publiziert Event über Event-Bus"""
        pass
    
    @abstractmethod
    async def publish_batch(self, events: List[Dict[str, Any]]) -> None:
        """Publiziert mehrere Events in Batch"""
        pass


class MLPredictionService(ABC):
    """Interface für ML-basierte Prediction Services"""
    
    @abstractmethod
    async def generate_prediction(self, 
                                market_data: MarketData, 
                                horizon: PredictionHorizon) -> Dict[str, Any]:
        """
        Generiert ML-basierte Prediction
        
        Returns:
            Dict mit:
            - profit_forecast: Decimal
            - confidence: float (0.0-1.0)
            - model_used: str
            - features_used: List[str]
        """
        pass
    
    @abstractmethod
    async def get_model_performance(self, horizon: PredictionHorizon) -> Dict[str, Any]:
        """Lädt Model Performance Metriken"""
        pass
    
    @abstractmethod
    async def retrain_models(self) -> Dict[str, Any]:
        """Triggert Model Retraining"""
        pass


class NotificationService(ABC):
    """Interface für Notification Services"""
    
    @abstractmethod
    async def send_performance_alert(self, 
                                   symbol: str, 
                                   performance_data: Dict[str, Any]) -> None:
        """Sendet Performance Alert"""
        pass
    
    @abstractmethod
    async def send_prediction_update(self, 
                                   symbol: str, 
                                   prediction_data: Dict[str, Any]) -> None:
        """Sendet Prediction Update Notification"""
        pass


class CacheService(ABC):
    """Interface für Caching Services"""
    
    @abstractmethod
    async def get(self, key: str) -> Optional[Any]:
        """Lädt Wert aus Cache"""
        pass
    
    @abstractmethod
    async def set(self, key: str, value: Any, ttl_seconds: int = 3600) -> None:
        """Speichert Wert in Cache"""
        pass
    
    @abstractmethod
    async def delete(self, key: str) -> None:
        """Löscht Wert aus Cache"""
        pass
    
    @abstractmethod
    async def clear_pattern(self, pattern: str) -> None:
        """Löscht alle Werte die Pattern matchen"""
        pass


class MetricsService(ABC):
    """Interface für Metrics und Monitoring"""
    
    @abstractmethod
    async def record_prediction_generated(self, 
                                        symbol: str, 
                                        horizon: PredictionHorizon,
                                        processing_time: float) -> None:
        """Recorded Prediction Generation Metric"""
        pass
    
    @abstractmethod
    async def record_performance_calculated(self, 
                                          symbol: str,
                                          processing_time: float,
                                          accuracy: Optional[float] = None) -> None:
        """Records Performance Calculation Metric"""
        pass
    
    @abstractmethod
    async def record_error(self, 
                         operation: str, 
                         error_type: str, 
                         symbol: Optional[str] = None) -> None:
        """Records Error Metric"""
        pass
    
    @abstractmethod
    async def get_service_metrics(self) -> Dict[str, Any]:
        """Lädt Service Metriken"""
        pass