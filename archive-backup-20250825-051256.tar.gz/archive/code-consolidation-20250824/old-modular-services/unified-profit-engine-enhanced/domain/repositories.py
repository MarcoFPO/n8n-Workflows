#!/usr/bin/env python3
"""
Domain Layer - Repository Interfaces
Unified Profit Engine Enhanced v6.0 - Clean Architecture

REPOSITORY PATTERN:
- Abstract Interfaces für Data Access
- Dependency Inversion Principle
- Domain-driven Design

Code-Qualität: HÖCHSTE PRIORITÄT - Clean Architecture Principles
Autor: Claude Code - Architecture Refactoring Specialist
Datum: 24. August 2025
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from datetime import date, datetime
from decimal import Decimal

from .entities import (
    ProfitPrediction, 
    SOLLISTTracking, 
    MarketSymbol, 
    PredictionHorizon
)


class ProfitPredictionRepository(ABC):
    """Repository Interface für Profit Predictions"""
    
    @abstractmethod
    async def save(self, prediction: ProfitPrediction) -> None:
        """Speichert eine Profit Prediction"""
        pass
    
    @abstractmethod
    async def get_by_id(self, prediction_id: str) -> Optional[ProfitPrediction]:
        """Lädt Prediction by ID"""
        pass
    
    @abstractmethod
    async def get_by_symbol(self, symbol: str) -> List[ProfitPrediction]:
        """Lädt alle Predictions für Symbol"""
        pass
    
    @abstractmethod
    async def get_by_date_range(self, 
                               start_date: date, 
                               end_date: date) -> List[ProfitPrediction]:
        """Lädt Predictions in Datumsbereich"""
        pass
    
    @abstractmethod
    async def update(self, prediction: ProfitPrediction) -> None:
        """Aktualisiert bestehende Prediction"""
        pass
    
    @abstractmethod
    async def delete(self, prediction_id: str) -> bool:
        """Löscht Prediction"""
        pass


class SOLLISTTrackingRepository(ABC):
    """Repository Interface für SOLL-IST Tracking"""
    
    @abstractmethod
    async def save(self, tracking: SOLLISTTracking) -> None:
        """Speichert SOLL-IST Tracking mit UPSERT Logic"""
        pass
    
    @abstractmethod
    async def get_by_symbol_and_date(self, 
                                   symbol: str, 
                                   datum: date) -> Optional[SOLLISTTracking]:
        """Lädt Tracking für Symbol und Datum"""
        pass
    
    @abstractmethod
    async def get_by_symbol(self, symbol: str) -> List[SOLLISTTracking]:
        """Lädt alle Tracking-Einträge für Symbol"""
        pass
    
    @abstractmethod
    async def get_by_date_range(self, 
                               start_date: date, 
                               end_date: date) -> List[SOLLISTTracking]:
        """Lädt Tracking-Einträge in Datumsbereich"""
        pass
    
    @abstractmethod
    async def get_performance_analysis(self, 
                                     symbol: Optional[str] = None,
                                     horizon: Optional[PredictionHorizon] = None) -> List[Dict[str, Any]]:
        """Lädt Performance-Analyse Daten"""
        pass
    
    @abstractmethod
    async def update(self, tracking: SOLLISTTracking) -> None:
        """Aktualisiert bestehende Tracking-Einträge"""
        pass
    
    @abstractmethod
    async def delete(self, tracking_id: str) -> bool:
        """Löscht Tracking-Eintrag"""
        pass


class MarketDataRepository(ABC):
    """Repository Interface für Market Data"""
    
    @abstractmethod
    async def get_current_data(self, symbol: str) -> 'MarketData':
        """Lädt aktuelle Marktdaten für Symbol"""
        pass
    
    @abstractmethod
    async def get_historical_data(self, 
                                symbol: str, 
                                days: int) -> List['MarketData']:
        """Lädt historische Marktdaten"""
        pass
    
    @abstractmethod
    async def get_company_info(self, symbol: str) -> Dict[str, Any]:
        """Lädt Company Information"""
        pass


# =============================================================================
# DATA TRANSFER OBJECTS für Repository Layer
# =============================================================================

from dataclasses import dataclass
from typing import Union


@dataclass
class MarketData:
    """Data Transfer Object für Market Data"""
    symbol: str
    company_name: str
    market_region: str
    current_price: Decimal
    volume: int
    historical_data: Dict[str, Any]
    timestamp: datetime
    
    # Optional additional data
    market_cap: Optional[Decimal] = None
    pe_ratio: Optional[float] = None
    dividend_yield: Optional[float] = None
    beta: Optional[float] = None


@dataclass
class PerformanceMetrics:
    """Data Transfer Object für Performance Metriken"""
    symbol: str
    tracking_date: date
    ist_gewinn: Optional[Decimal]
    
    # SOLL-Werte pro Horizont
    soll_1w: Optional[Decimal]
    soll_1m: Optional[Decimal] 
    soll_3m: Optional[Decimal]
    soll_12m: Optional[Decimal]
    
    # Performance Differences
    diff_1w: Optional[Decimal]
    diff_1m: Optional[Decimal]
    diff_3m: Optional[Decimal] 
    diff_12m: Optional[Decimal]
    
    # Accuracy Percentages
    accuracy_1w: Optional[float]
    accuracy_1m: Optional[float]
    accuracy_3m: Optional[float]
    accuracy_12m: Optional[float]
    
    # Metadata
    best_horizon: Optional[str]
    worst_horizon: Optional[str]
    overall_accuracy: Optional[float]