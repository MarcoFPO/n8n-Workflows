#!/usr/bin/env python3
"""
Domain Layer - Business Entities
Unified Profit Engine Enhanced v6.0 - Clean Architecture

DOMAIN LAYER RESPONSIBILITIES:
- Core Business Logic
- Business Rules Enforcement
- Domain Events
- Value Objects und Entities

Code-Qualität: HÖCHSTE PRIORITÄT - Clean Architecture Principles
Autor: Claude Code - Architecture Refactoring Specialist
Datum: 24. August 2025
"""

from datetime import datetime, date, timedelta
from decimal import Decimal
from typing import Dict, List, Optional, Any
from uuid import uuid4
from enum import Enum
from dataclasses import dataclass
from abc import ABC, abstractmethod


class PredictionHorizon(Enum):
    """Value Object für Prediction Horizonte"""
    ONE_WEEK = "1W"
    ONE_MONTH = "1M" 
    THREE_MONTHS = "3M"
    TWELVE_MONTHS = "12M"
    
    @property
    def days(self) -> int:
        """Konvertiert Horizont zu Tagen"""
        horizon_days = {
            "1W": 7, "1M": 30, "3M": 90, "12M": 365
        }
        return horizon_days[self.value]
    
    @property
    def display_name(self) -> str:
        """Human-readable Name"""
        names = {
            "1W": "1 Woche", "1M": "1 Monat", 
            "3M": "3 Monate", "12M": "12 Monate"
        }
        return names[self.value]


@dataclass(frozen=True)
class MarketSymbol:
    """Value Object für Aktien-Symbole mit Business Rules"""
    symbol: str
    company_name: str
    market_region: str
    
    def __post_init__(self):
        """Domain Rules Validation"""
        if not self.symbol or len(self.symbol) < 1:
            raise ValueError("Symbol cannot be empty")
        if not self.company_name:
            raise ValueError("Company name is required")
        if self.market_region not in ["US", "EU", "ASIA", "GLOBAL"]:
            raise ValueError(f"Invalid market region: {self.market_region}")
    
    @property
    def identifier(self) -> str:
        """Unique identifier for the symbol"""
        return f"{self.market_region}:{self.symbol}"


@dataclass(frozen=True) 
class ProfitForecast:
    """Value Object für Gewinnvorhersagen mit Business Logic"""
    amount: Decimal
    confidence: float
    horizon: PredictionHorizon
    
    def __post_init__(self):
        """Business Rules Validation"""
        if self.confidence < 0.0 or self.confidence > 1.0:
            raise ValueError("Confidence must be between 0.0 and 1.0")
        if self.amount < Decimal('-999999') or self.amount > Decimal('999999'):
            raise ValueError("Forecast amount out of valid range")
    
    @property
    def is_positive_forecast(self) -> bool:
        """Business Logic: Ist die Vorhersage positiv?"""
        return self.amount > Decimal('0')
    
    @property
    def confidence_level(self) -> str:
        """Business Logic: Confidence Level Kategorisierung"""
        if self.confidence >= 0.8:
            return "HIGH"
        elif self.confidence >= 0.6:
            return "MEDIUM"
        else:
            return "LOW"


class ProfitPrediction:
    """Entity für Gewinnvorhersagen - Aggregate Root"""
    
    def __init__(self, 
                 symbol: MarketSymbol,
                 target_date: date,
                 forecasts: Dict[PredictionHorizon, ProfitForecast]):
        self.id = str(uuid4())
        self.symbol = symbol
        self.target_date = target_date
        self._forecasts = forecasts
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
        
        # Domain Events
        self._domain_events: List['DomainEvent'] = []
        
        # Business Rules Validation
        self._validate_business_rules()
    
    def _validate_business_rules(self):
        """Domain Business Rules Enforcement"""
        if not self._forecasts:
            raise ValueError("At least one forecast is required")
        
        if self.target_date <= date.today():
            raise ValueError("Target date must be in the future")
    
    @property
    def forecasts(self) -> Dict[PredictionHorizon, ProfitForecast]:
        """Read-only access to forecasts"""
        return self._forecasts.copy()
    
    def update_forecast(self, horizon: PredictionHorizon, forecast: ProfitForecast):
        """Business Logic: Update Forecast with Domain Event"""
        old_forecast = self._forecasts.get(horizon)
        self._forecasts[horizon] = forecast
        self.updated_at = datetime.now()
        
        # Domain Event
        self._domain_events.append(
            PredictionUpdatedEvent(
                prediction_id=self.id,
                symbol=self.symbol.symbol,
                horizon=horizon,
                old_forecast=old_forecast,
                new_forecast=forecast,
                occurred_at=datetime.now()
            )
        )
    
    def calculate_target_date_for_horizon(self, horizon: PredictionHorizon) -> date:
        """Domain Logic: Berechnet Zieldatum basierend auf Horizont"""
        return self.target_date + timedelta(days=horizon.days)
    
    def get_best_forecast(self) -> tuple[PredictionHorizon, ProfitForecast]:
        """Business Logic: Beste Vorhersage basierend auf Confidence"""
        if not self._forecasts:
            raise ValueError("No forecasts available")
        
        return max(
            self._forecasts.items(),
            key=lambda item: item[1].confidence
        )
    
    def clear_domain_events(self) -> List['DomainEvent']:
        """Domain Events auslesen und löschen"""
        events = self._domain_events.copy()
        self._domain_events.clear()
        return events


class SOLLISTTracking:
    """Aggregate Root für SOLL-IST Performance Tracking"""
    
    def __init__(self, 
                 datum: date, 
                 symbol: MarketSymbol):
        self.id = str(uuid4())
        self.datum = datum
        self.symbol = symbol
        
        # SOLL-Werte (Vorhersagen)
        self._soll_values: Dict[PredictionHorizon, Optional[Decimal]] = {
            horizon: None for horizon in PredictionHorizon
        }
        
        # IST-Werte (tatsächliche Performance)
        self.ist_gewinn: Optional[Decimal] = None
        self.ist_calculated_at: Optional[datetime] = None
        
        # Timestamps
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
        
        # Domain Events
        self._domain_events: List['DomainEvent'] = []
    
    def update_soll_gewinn(self, horizon: PredictionHorizon, profit: Decimal):
        """Domain Logic für SOLL-Gewinn Updates"""
        if profit is None:
            raise ValueError("SOLL profit cannot be None")
        
        old_value = self._soll_values[horizon]
        self._soll_values[horizon] = profit
        self.updated_at = datetime.now()
        
        # Domain Event
        self._domain_events.append(
            SOLLValueUpdatedEvent(
                tracking_id=self.id,
                symbol=self.symbol.symbol,
                horizon=horizon,
                old_value=old_value,
                new_value=profit,
                occurred_at=datetime.now()
            )
        )
    
    def update_ist_gewinn(self, profit: Decimal):
        """Domain Logic für IST-Gewinn Updates"""
        if profit is None:
            raise ValueError("IST profit cannot be None")
        
        old_value = self.ist_gewinn
        self.ist_gewinn = profit
        self.ist_calculated_at = datetime.now()
        self.updated_at = datetime.now()
        
        # Domain Event
        self._domain_events.append(
            ISTValueUpdatedEvent(
                tracking_id=self.id,
                symbol=self.symbol.symbol,
                old_value=old_value,
                new_value=profit,
                occurred_at=datetime.now()
            )
        )
    
    def get_soll_gewinn(self, horizon: PredictionHorizon) -> Optional[Decimal]:
        """SOLL-Gewinn für bestimmten Horizont abrufen"""
        return self._soll_values[horizon]
    
    def calculate_performance_diff(self, horizon: PredictionHorizon) -> Optional[Decimal]:
        """Business Logic: Berechnet IST-SOLL Differenz"""
        if self.ist_gewinn is None:
            return None
        
        soll_value = self._soll_values[horizon]
        if soll_value is None:
            return None
        
        return self.ist_gewinn - soll_value
    
    def calculate_accuracy_percentage(self, horizon: PredictionHorizon) -> Optional[float]:
        """Business Logic: Accuracy Percentage für Horizont"""
        diff = self.calculate_performance_diff(horizon)
        soll_value = self._soll_values[horizon]
        
        if diff is None or soll_value is None or soll_value == 0:
            return None
        
        return float(1 - (abs(diff) / abs(soll_value)))
    
    def get_best_performing_horizon(self) -> Optional[PredictionHorizon]:
        """Business Logic: Bester performender Horizont"""
        accuracies = {}
        
        for horizon in PredictionHorizon:
            accuracy = self.calculate_accuracy_percentage(horizon)
            if accuracy is not None:
                accuracies[horizon] = accuracy
        
        if not accuracies:
            return None
        
        return max(accuracies, key=accuracies.get)
    
    def clear_domain_events(self) -> List['DomainEvent']:
        """Domain Events auslesen und löschen"""
        events = self._domain_events.copy()
        self._domain_events.clear()
        return events
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialisierung für Events"""
        return {
            "id": self.id,
            "datum": self.datum.isoformat(),
            "symbol": self.symbol.symbol,
            "company_name": self.symbol.company_name,
            "market_region": self.symbol.market_region,
            "ist_gewinn": float(self.ist_gewinn) if self.ist_gewinn else None,
            "soll_gewinn_1w": float(self._soll_values[PredictionHorizon.ONE_WEEK]) if self._soll_values[PredictionHorizon.ONE_WEEK] else None,
            "soll_gewinn_1m": float(self._soll_values[PredictionHorizon.ONE_MONTH]) if self._soll_values[PredictionHorizon.ONE_MONTH] else None,
            "soll_gewinn_3m": float(self._soll_values[PredictionHorizon.THREE_MONTHS]) if self._soll_values[PredictionHorizon.THREE_MONTHS] else None,
            "soll_gewinn_12m": float(self._soll_values[PredictionHorizon.TWELVE_MONTHS]) if self._soll_values[PredictionHorizon.TWELVE_MONTHS] else None,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }


# =============================================================================
# DOMAIN EVENTS
# =============================================================================

class DomainEvent(ABC):
    """Base Class für Domain Events"""
    
    def __init__(self, occurred_at: datetime = None):
        self.event_id = str(uuid4())
        self.occurred_at = occurred_at or datetime.now()
    
    @abstractmethod
    def event_type(self) -> str:
        """Event Type Identifier"""
        pass


@dataclass(frozen=True)
class PredictionUpdatedEvent(DomainEvent):
    """Domain Event: Prediction wurde aktualisiert"""
    prediction_id: str
    symbol: str
    horizon: PredictionHorizon
    old_forecast: Optional[ProfitForecast]
    new_forecast: ProfitForecast
    occurred_at: datetime
    
    def event_type(self) -> str:
        return "profit.prediction.updated"


@dataclass(frozen=True)
class SOLLValueUpdatedEvent(DomainEvent):
    """Domain Event: SOLL-Wert wurde aktualisiert"""
    tracking_id: str
    symbol: str
    horizon: PredictionHorizon
    old_value: Optional[Decimal]
    new_value: Decimal
    occurred_at: datetime
    
    def event_type(self) -> str:
        return "profit.soll.updated"


@dataclass(frozen=True)
class ISTValueUpdatedEvent(DomainEvent):
    """Domain Event: IST-Wert wurde aktualisiert"""
    tracking_id: str
    symbol: str
    old_value: Optional[Decimal]
    new_value: Decimal
    occurred_at: datetime
    
    def event_type(self) -> str:
        return "profit.ist.updated"


@dataclass(frozen=True)
class PredictionCreatedEvent(DomainEvent):
    """Domain Event: Neue Prediction wurde erstellt"""
    prediction_id: str
    symbol: str
    forecasts: Dict[PredictionHorizon, ProfitForecast]
    occurred_at: datetime
    
    def event_type(self) -> str:
        return "profit.prediction.created"