#!/bin/bash
#
# Clean Data Analysis Service Deployment Script
# Production Deployment auf Server 10.1.1.174
#
# Author: Claude Code & Aktienanalyse Team
# Version: 1.0.0
# Date: 2024-08-24
#

set -e

echo "🚀 Clean Data Analysis Service Deployment v1.0.0"
echo "🏗️ Production Deployment Script"
echo "========================================================="

# Configuration
SERVICE_NAME="clean-data-analysis"
SERVICE_PORT=8002
SERVICE_USER="aktienanalyse"
PROJECT_DIR="/home/mdoehler/aktienanalyse-ökosystem/services/calculation-engine"
VENV_DIR="/home/mdoehler/aktienanalyse-venv"

echo "📋 Deployment Configuration:"
echo "   - Service: $SERVICE_NAME"
echo "   - Port: $SERVICE_PORT"
echo "   - User: $SERVICE_USER"
echo "   - Directory: $PROJECT_DIR"

# Step 1: Install Dependencies
echo ""
echo "📦 Step 1: Installing Dependencies..."
source "$VENV_DIR/bin/activate"
pip install --quiet fastapi uvicorn aiohttp requests asyncpg yfinance pandas
echo "✅ Dependencies installed"

# Step 2: Create systemd service
echo ""
echo "🔧 Step 2: Creating systemd service..."

sudo tee /etc/systemd/system/$SERVICE_NAME.service > /dev/null << EOF
[Unit]
Description=Clean Data Analysis Service
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=exec
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$PROJECT_DIR
Environment=PATH=$VENV_DIR/bin
ExecStart=$VENV_DIR/bin/python $PROJECT_DIR/clean_data_analysis_service_v1.0.0_20250824.py
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal
SyslogIdentifier=$SERVICE_NAME

[Install]
WantedBy=multi-user.target
EOF

echo "✅ systemd service created: $SERVICE_NAME.service"

# Step 3: Reload systemd and enable service
echo ""
echo "🔄 Step 3: Configuring systemd..."
sudo systemctl daemon-reload
sudo systemctl enable $SERVICE_NAME
echo "✅ Service enabled for auto-start"

# Step 4: Start service
echo ""
echo "▶️ Step 4: Starting service..."
sudo systemctl restart $SERVICE_NAME

# Wait for service to start
echo "⏱️ Waiting for service to start..."
sleep 5

# Step 5: Check service status
echo ""
echo "📊 Step 5: Service Status Check..."
if sudo systemctl is-active --quiet $SERVICE_NAME; then
    echo "✅ Service is running"
    sudo systemctl status $SERVICE_NAME --no-pager -l
else
    echo "❌ Service failed to start"
    sudo systemctl status $SERVICE_NAME --no-pager -l
    sudo journalctl -u $SERVICE_NAME --no-pager -l | tail -20
    exit 1
fi

# Step 6: Health check
echo ""
echo "🏥 Step 6: Health Check..."
if command -v curl &> /dev/null; then
    if curl -f -s "http://localhost:$SERVICE_PORT/api/v1/health" > /dev/null; then
        echo "✅ Health check passed"
        curl -s "http://localhost:$SERVICE_PORT/api/v1/health" | python3 -m json.tool
    else
        echo "❌ Health check failed"
        exit 1
    fi
else
    echo "⚠️ curl not available - skipping health check"
fi

# Step 7: Test API
echo ""
echo "🧪 Step 7: API Test..."
if command -v curl &> /dev/null; then
    echo "Testing predictions API..."
    curl -X POST "http://localhost:$SERVICE_PORT/api/v1/predictions/generate" \
         -H "Content-Type: application/json" \
         -d '{"symbols": ["AAPL"]}' \
         -s | python3 -m json.tool | head -20
    echo "✅ API test completed"
else
    echo "⚠️ curl not available - skipping API test"
fi

echo ""
echo "🎉 Deployment Completed Successfully!"
echo "========================================================="
echo "Service Information:"
echo "   - Service: $SERVICE_NAME"
echo "   - Status: $(sudo systemctl is-active $SERVICE_NAME)"
echo "   - Port: $SERVICE_PORT"
echo "   - Health: http://localhost:$SERVICE_PORT/api/v1/health"
echo "   - Logs: sudo journalctl -u $SERVICE_NAME -f"
echo ""
echo "Management Commands:"
echo "   - Start:   sudo systemctl start $SERVICE_NAME"
echo "   - Stop:    sudo systemctl stop $SERVICE_NAME"  
echo "   - Restart: sudo systemctl restart $SERVICE_NAME"
echo "   - Status:  sudo systemctl status $SERVICE_NAME"
echo "   - Logs:    sudo journalctl -u $SERVICE_NAME -f"
echo ""