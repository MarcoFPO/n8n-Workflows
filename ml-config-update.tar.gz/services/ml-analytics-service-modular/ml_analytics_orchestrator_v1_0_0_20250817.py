#!/usr/bin/env python3
"""
ML Analytics Service Orchestrator v1.0.0
Hauptorchestrator für alle ML-Operationen im aktienanalyse-ökosystem

Integration: Event-Driven Architecture (Port 8021)
Autor: Claude Code
Datum: 17. August 2025
"""

import asyncio
import logging
import signal
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional

import uvicorn
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

# Add project root to Python path
sys.path.append(str(Path(__file__).parent.parent.parent))

# Import shared modules
from shared.event_bus import EventBusConnection
from shared.database import DatabaseConnection
from shared.logging_config import setup_logging

# Import ML modules
from modules.feature_engineering.technical_feature_engine_v1_0_0_20250817 import TechnicalFeatureEngine
from modules.model_management.model_manager_v1_0_0_20250817 import ModelManager
from modules.prediction_engine.prediction_orchestrator_v1_0_0_20250817 import PredictionOrchestrator
from modules.training.training_orchestrator_v1_0_0_20250817 import TrainingOrchestrator
from modules.monitoring.performance_tracker_v1_0_0_20250817 import PerformanceTracker

# Import API modules
from api.ml_api_endpoints_v1_0_0_20250817 import create_ml_api_router

# Import configuration
from config.ml_service_config import ML_SERVICE_CONFIG

# Setup logging
logger = setup_logging("ml-analytics", ML_SERVICE_CONFIG['service']['port'])


class MLAnalyticsService:
    """
    ML Analytics Service Orchestrator
    Verwaltet alle ML-Operationen im Event-Driven System
    """
    
    def __init__(self):
        self.service_name = "ml-analytics"
        self.service_port = ML_SERVICE_CONFIG['service']['port']
        
        # Core Components
        self.feature_engine = None
        self.model_manager = None
        self.prediction_orchestrator = None
        self.training_orchestrator = None
        self.performance_tracker = None
        
        # Infrastructure
        self.event_bus = None
        self.database = None
        self.app = None
        
        # Service State
        self.is_healthy = False
        self.startup_time = None
        self.shutdown_requested = False
        
    async def initialize_components(self):
        """Initialisiert alle Service-Komponenten"""
        try:
            logger.info("Initializing ML Analytics Service components...")
            
            # Database Connection
            db_config = {
                'host': ML_SERVICE_CONFIG['database']['host'],
                'port': ML_SERVICE_CONFIG['database']['port'],
                'database': ML_SERVICE_CONFIG['database']['name'],
                'user': ML_SERVICE_CONFIG['database']['user'],
                'password': ML_SERVICE_CONFIG['database']['password']
            }
            self.database = DatabaseConnection(db_config)
            await self.database.connect()
            logger.info("Database connection established")
            
            # Event Bus Connection
            self.event_bus = EventBusConnection(
                service_name=self.service_name,
                consumer_group="ml-analytics-group"
            )
            await self.event_bus.connect()
            logger.info("Event Bus connection established")
            
            # Initialize Core Components
            self.feature_engine = TechnicalFeatureEngine(
                database=self.database,
                event_bus=self.event_bus
            )
            
            self.model_manager = ModelManager(
                database=self.database,
                event_bus=self.event_bus
            )
            
            self.prediction_orchestrator = PredictionOrchestrator(
                feature_engine=self.feature_engine,
                model_manager=self.model_manager,
                database=self.database,
                event_bus=self.event_bus
            )
            
            self.training_orchestrator = TrainingOrchestrator(
                database=self.database,
                event_bus=self.event_bus,
                model_manager=self.model_manager
            )
            
            self.performance_tracker = PerformanceTracker(
                database=self.database,
                event_bus=self.event_bus
            )
            
            # Initialize components
            await self.feature_engine.initialize()
            await self.model_manager.initialize()
            await self.prediction_orchestrator.initialize()
            await self.training_orchestrator.initialize()
            await self.performance_tracker.initialize()
            
            logger.info("All ML components initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize components: {str(e)}")
            logger.error(traceback.format_exc())
            raise
    
    async def setup_event_handlers(self):
        """Konfiguriert Event-Handler für ML-Events"""
        try:
            # Market Data Events
            await self.event_bus.subscribe(
                'market.data.updated',
                self.handle_market_data_updated
            )
            
            # Intelligence Events
            await self.event_bus.subscribe(
                'intelligence.triggered',
                self.handle_intelligence_triggered
            )
            
            # ML Feature Events
            await self.event_bus.subscribe(
                'ml.features.calculated',
                self.handle_ml_features_calculated
            )
            
            # Performance Events
            await self.event_bus.subscribe(
                'ml.performance.threshold.crossed',
                self.handle_performance_threshold_crossed
            )
            
            logger.info("Event handlers configured successfully")
            
        except Exception as e:
            logger.error(f"Failed to setup event handlers: {str(e)}")
            raise
    
    async def handle_market_data_updated(self, event: Dict[str, Any]):
        """Verarbeitet market.data.updated Events"""
        try:
            symbol = event.get('payload', {}).get('symbol')
            if not symbol:
                logger.warning("Received market.data.updated without symbol")
                return
            
            logger.info(f"Processing market data update for {symbol}")
            
            # Feature Engineering auslösen
            await self.feature_engine.calculate_features_for_symbol(symbol, event)
            
        except Exception as e:
            logger.error(f"Failed to handle market_data_updated: {str(e)}")
    
    async def handle_intelligence_triggered(self, event: Dict[str, Any]):
        """Erweitert Intelligence Events mit ML-Insights"""
        try:
            symbol = event.get('payload', {}).get('symbol')
            if symbol:
                # ML-Insights hinzufügen
                predictions = await self.prediction_orchestrator.get_latest_predictions(symbol)
                if predictions:
                    enhanced_payload = {
                        **event.get('payload', {}),
                        'ml_insights': {
                            'predictions': predictions,
                            'confidence_level': predictions.get('ensemble', {}).get('7d', {}).get('ensemble_confidence', 0.0),
                            'recommendation_strength': self._calculate_recommendation_strength(predictions)
                        }
                    }
                    
                    await self.event_bus.publish('intelligence.ml.enhanced', enhanced_payload)
            
        except Exception as e:
            logger.error(f"Failed to handle intelligence_triggered: {str(e)}")
    
    async def handle_ml_features_calculated(self, event: Dict[str, Any]):
        """Verarbeitet ml.features.calculated Events"""
        try:
            symbol = event.get('payload', {}).get('symbol')
            features = event.get('payload', {}).get('features')
            
            if symbol and features:
                # Predictions generieren
                await self.prediction_orchestrator.generate_predictions(symbol, features)
            
        except Exception as e:
            logger.error(f"Failed to handle ml_features_calculated: {str(e)}")
    
    async def handle_performance_threshold_crossed(self, event: Dict[str, Any]):
        """Verarbeitet Performance-Threshold-Events"""
        try:
            payload = event.get('payload', {})
            model_type = payload.get('model_type')
            horizon_days = payload.get('horizon_days')
            direction = payload.get('direction')
            
            if direction == 'below' and model_type and horizon_days:
                logger.warning(f"Performance threshold crossed for {model_type} {horizon_days}d")
                
                # Retraining auslösen
                training_id = await self.training_orchestrator.start_training(
                    model_type=model_type,
                    horizon_days=horizon_days,
                    trigger_event_id=event.get('event_id')
                )
                
                logger.info(f"Triggered retraining {training_id} due to performance degradation")
            
        except Exception as e:
            logger.error(f"Failed to handle performance_threshold_crossed: {str(e)}")
    
    def _calculate_recommendation_strength(self, predictions: Dict[str, Any]) -> str:
        """Berechnet Empfehlungsstärke basierend auf ML-Predictions"""
        try:
            ensemble_7d = predictions.get('ensemble', {}).get('7d', {})
            confidence = ensemble_7d.get('ensemble_confidence', 0.0)
            prediction_values = ensemble_7d.get('prediction_values', [])
            
            if not prediction_values:
                return "NEUTRAL"
            
            avg_change = sum(prediction_values) / len(prediction_values)
            
            if confidence > 0.8:
                if avg_change > 5.0:
                    return "STRONG_BUY"
                elif avg_change > 2.0:
                    return "BUY"
                elif avg_change < -5.0:
                    return "STRONG_SELL"
                elif avg_change < -2.0:
                    return "SELL"
            elif confidence > 0.6:
                if avg_change > 3.0:
                    return "MODERATE_BUY"
                elif avg_change < -3.0:
                    return "MODERATE_SELL"
            
            return "NEUTRAL"
            
        except Exception as e:
            logger.error(f"Failed to calculate recommendation strength: {str(e)}")
            return "NEUTRAL"
    
    async def health_check(self) -> Dict[str, Any]:
        """Comprehensive Health Check"""
        try:
            health_status = {
                'service': 'ml-analytics',
                'version': '1.0.0',
                'status': 'healthy',
                'timestamp': datetime.utcnow().isoformat(),
                'uptime_seconds': (datetime.utcnow() - self.startup_time).total_seconds() if self.startup_time else 0,
                'components': {}
            }
            
            # Component Health Checks
            if self.database:
                health_status['components']['database'] = await self.database.health_check()
            
            if self.event_bus:
                health_status['components']['event_bus'] = await self.event_bus.health_check()
            
            if self.model_manager:
                health_status['components']['models'] = await self.model_manager.health_check()
            
            if self.feature_engine:
                health_status['components']['feature_engine'] = await self.feature_engine.health_check()
            
            # Overall Status
            component_statuses = [comp.get('status', 'unknown') for comp in health_status['components'].values()]
            if all(status == 'healthy' for status in component_statuses):
                health_status['status'] = 'healthy'
                self.is_healthy = True
            elif any(status == 'critical' for status in component_statuses):
                health_status['status'] = 'critical'
                self.is_healthy = False
            else:
                health_status['status'] = 'warning'
                self.is_healthy = True
            
            return health_status
            
        except Exception as e:
            logger.error(f"Health check failed: {str(e)}")
            self.is_healthy = False
            return {
                'service': 'ml-analytics',
                'status': 'critical',
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    async def graceful_shutdown(self):
        """Graceful Service Shutdown"""
        try:
            logger.info("Starting graceful shutdown...")
            self.shutdown_requested = True
            
            # Stop accepting new requests
            if self.app:
                logger.info("Stopping FastAPI application...")
            
            # Close component connections
            if self.training_orchestrator:
                await self.training_orchestrator.shutdown()
            
            if self.prediction_orchestrator:
                await self.prediction_orchestrator.shutdown()
            
            if self.model_manager:
                await self.model_manager.shutdown()
            
            if self.feature_engine:
                await self.feature_engine.shutdown()
            
            if self.performance_tracker:
                await self.performance_tracker.shutdown()
            
            # Close infrastructure connections
            if self.event_bus:
                await self.event_bus.disconnect()
                logger.info("Event Bus disconnected")
            
            if self.database:
                await self.database.disconnect()
                logger.info("Database disconnected")
            
            logger.info("Graceful shutdown completed")
            
        except Exception as e:
            logger.error(f"Error during shutdown: {str(e)}")


# Global service instance
ml_service = MLAnalyticsService()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """FastAPI Lifespan Manager"""
    # Startup
    try:
        logger.info("Starting ML Analytics Service...")
        ml_service.startup_time = datetime.utcnow()
        
        await ml_service.initialize_components()
        await ml_service.setup_event_handlers()
        
        logger.info(f"ML Analytics Service started successfully on port {ML_SERVICE_CONFIG['service']['port']}")
        yield
        
    except Exception as e:
        logger.error(f"Failed to start service: {str(e)}")
        raise
    
    # Shutdown
    finally:
        await ml_service.graceful_shutdown()


# FastAPI Application
app = FastAPI(
    title="ML Analytics Service",
    description="Machine Learning Analytics Service für aktienanalyse-ökosystem",
    version="1.0.0",
    lifespan=lifespan
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8080", "https://10.1.1.174"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health Check Endpoint
@app.get("/health")
async def health_endpoint():
    """Service Health Check"""
    return await ml_service.health_check()

# Include ML API Router
ml_api_router = create_ml_api_router(ml_service)
app.include_router(ml_api_router, prefix="/api/v1")

# Store app reference
ml_service.app = app


def signal_handler(signum, frame):
    """Signal Handler for Graceful Shutdown"""
    logger.info(f"Received signal {signum}, initiating graceful shutdown...")
    asyncio.create_task(ml_service.graceful_shutdown())
    sys.exit(0)


if __name__ == "__main__":
    # Signal Handlers
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        # Start Service
        uvicorn.run(
            "ml_analytics_orchestrator_v1_0_0_20250817:app",
            host=ML_SERVICE_CONFIG['service']['host'],
            port=ML_SERVICE_CONFIG['service']['port'],
            workers=1,  # Single worker für ML-Service
            log_level="info",
            access_log=True,
            reload=False
        )
        
    except Exception as e:
        logger.error(f"Failed to start ML Analytics Service: {str(e)}")
        sys.exit(1)