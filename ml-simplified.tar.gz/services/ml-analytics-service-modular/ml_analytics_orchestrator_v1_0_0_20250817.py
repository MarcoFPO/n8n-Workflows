#!/usr/bin/env python3
"""
ML Analytics Service Orchestrator v1.0.0
Hauptorchestrator für alle ML-Operationen im aktienanalyse-ökosystem

Integration: Event-Driven Architecture (Port 8021)
Autor: Claude Code
Datum: 17. August 2025
"""

import asyncio
import logging
import signal
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional

import uvicorn
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

# Add project root to Python path
project_root = str(Path(__file__).parent.parent.parent)
sys.path.insert(0, project_root)

# Import configuration
from config.ml_service_config import ML_SERVICE_CONFIG

# Setup simple logging
logging.basicConfig(
    level=logging.INFO,
    format='{"service": "ml-analytics", "level": "%(levelname)s", "message": "%(message)s", "timestamp": "%(asctime)s"}'
)
logger = logging.getLogger("ml-analytics")


class MLAnalyticsService:
    """
    ML Analytics Service Orchestrator
    Verwaltet alle ML-Operationen im Event-Driven System
    """
    
    def __init__(self):
        self.service_name = "ml-analytics"
        self.service_port = ML_SERVICE_CONFIG['service']['port']
        
        # Infrastructure
        self.database = None
        self.app = None
        
        # Service State
        self.is_healthy = False
        self.startup_time = None
        self.shutdown_requested = False
        
    async def initialize_components(self):
        """Initialisiert alle Service-Komponenten"""
        try:
            logger.info("Initializing ML Analytics Service components...")
            
            # For now, just basic initialization to get the service running
            logger.info("Basic ML Analytics Service initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize components: {str(e)}")
            logger.error(traceback.format_exc())
            raise
    
    async def setup_event_handlers(self):
        """Konfiguriert Event-Handler für ML-Events"""
        try:
            # For now, just log that event handlers would be set up
            logger.info("Event handlers setup (placeholder)")
            
        except Exception as e:
            logger.error(f"Failed to setup event handlers: {str(e)}")
            raise
    
    def _calculate_recommendation_strength(self, predictions: Dict[str, Any]) -> str:
        """Berechnet Empfehlungsstärke basierend auf ML-Predictions (placeholder)"""
        return "NEUTRAL"
    
    async def health_check(self) -> Dict[str, Any]:
        """Basic Health Check"""
        try:
            health_status = {
                'service': 'ml-analytics',
                'version': '1.0.0',
                'status': 'healthy',
                'timestamp': datetime.utcnow().isoformat(),
                'uptime_seconds': (datetime.utcnow() - self.startup_time).total_seconds() if self.startup_time else 0,
                'port': self.service_port
            }
            
            self.is_healthy = True
            return health_status
            
        except Exception as e:
            logger.error(f"Health check failed: {str(e)}")
            self.is_healthy = False
            return {
                'service': 'ml-analytics',
                'status': 'critical',
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    async def graceful_shutdown(self):
        """Graceful Service Shutdown"""
        try:
            logger.info("Starting graceful shutdown...")
            self.shutdown_requested = True
            
            # Stop accepting new requests
            if self.app:
                logger.info("Stopping FastAPI application...")
            
            logger.info("Graceful shutdown completed")
            
        except Exception as e:
            logger.error(f"Error during shutdown: {str(e)}")


# Global service instance
ml_service = MLAnalyticsService()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """FastAPI Lifespan Manager"""
    # Startup
    try:
        logger.info("Starting ML Analytics Service...")
        ml_service.startup_time = datetime.utcnow()
        
        await ml_service.initialize_components()
        await ml_service.setup_event_handlers()
        
        logger.info(f"ML Analytics Service started successfully on port {ML_SERVICE_CONFIG['service']['port']}")
        yield
        
    except Exception as e:
        logger.error(f"Failed to start service: {str(e)}")
        raise
    
    # Shutdown
    finally:
        await ml_service.graceful_shutdown()


# FastAPI Application
app = FastAPI(
    title="ML Analytics Service",
    description="Machine Learning Analytics Service für aktienanalyse-ökosystem",
    version="1.0.0",
    lifespan=lifespan
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8080", "https://10.1.1.174"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health Check Endpoint
@app.get("/health")
async def health_endpoint():
    """Service Health Check"""
    return await ml_service.health_check()

# Simple ML API endpoints for now
@app.get("/api/v1/status")
async def get_ml_status():
    """Get ML service status"""
    return {"status": "active", "service": "ml-analytics", "version": "1.0.0"}

@app.get("/api/v1/predictions/{symbol}")
async def get_predictions(symbol: str):
    """Get predictions for symbol (placeholder)"""
    return {"symbol": symbol, "predictions": [], "message": "ML pipeline not yet fully implemented"}

# Store app reference
ml_service.app = app


def signal_handler(signum, frame):
    """Signal Handler for Graceful Shutdown"""
    logger.info(f"Received signal {signum}, initiating graceful shutdown...")
    asyncio.create_task(ml_service.graceful_shutdown())
    sys.exit(0)


if __name__ == "__main__":
    # Signal Handlers
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        # Start Service
        uvicorn.run(
            "ml_analytics_orchestrator_v1_0_0_20250817:app",
            host=ML_SERVICE_CONFIG['service']['host'],
            port=ML_SERVICE_CONFIG['service']['port'],
            workers=1,  # Single worker für ML-Service
            log_level="info",
            access_log=True,
            reload=False
        )
        
    except Exception as e:
        logger.error(f"Failed to start ML Analytics Service: {str(e)}")
        sys.exit(1)